# AI Agen

Aplikasi Android untuk mengelola 7 slot akun (Gemini, Claude, ChatGPT, Flow)
dalam satu aplikasi. Tiap slot login manual satu kali lewat halaman resmi
layanannya di dalam WebView; sesinya disimpan terpisah per slot (proses
Android sendiri-sendiri), jadi berpindah slot tidak perlu logout/login ulang.

Ini BUKAN aplikasi kloning yang menjalankan aplikasi lain secara paralel —
ini hanya membuka situs resmi tiap layanan AI di WebView dengan penyimpanan
cookie/local storage yang terisolasi per slot, seperti profil terpisah di
browser.

## Versi 1.3 - yang baru

- Saat layanan dipilih di dialog slot (Claude/Gemini/ChatGPT/Flow), kolom URL
  dan nama slot terisi otomatis sesuai layanan, dengan nomor lanjutan
  (mis. Claude 3, Gemini 7). Slot baru juga memakai penomoran yang sama.

## Versi 1.2

- Suara: mikrofon di situs AI (mode suara, dikte) lewat izin yang ditanya dulu.
- Kamera: panggilan video, dan tombol lampiran menawarkan foto langsung dari kamera.
- Navigasi: bar bawah (kembali, maju, muat ulang, halaman awal), nama situs di
  bawah judul, menu salin link dan buka di browser, serta izin lokasi untuk peta.
- Setiap izin mikrofon, kamera, dan lokasi ditanya dulu per situs.

## Versi 1.1

- Layar web bisa digulir normal (pull-to-refresh dihapus). Muat ulang lewat
  menu tiga titik di pojok kanan atas slot.
- Tombol **Tambah slot** (maksimal 20). Tekan lama kartu slot untuk mengubah
  atau menghapus slot (sesi login slot itu ikut dihapus).
- Ikon tiap layanan AI diambil dari ikon situs resminya.
- Lampiran/unggah file dari HP bekerja di semua layanan, dan unduhan file
  disimpan ke folder Download.
- Menu "Keluar dari akun" di dalam slot untuk menghapus sesinya.

## Cara build lewat GitHub dengan unggah zip

Unggah zip ini apa adanya ke repository, lalu pakai workflow yang
mengekstrak zip otomatis (lihat penjelasan dari Claude).

## Cara build lewat GitHub (tanpa Android Studio)

1. Buat repo baru di GitHub, lalu push semua isi folder ini:
   ```
   git init
   git add .
   git commit -m "Initial commit: AI Agen"
   git branch -M main
   git remote add origin <URL_REPO_ANDA>
   git push -u origin main
   ```
2. Buka tab **Actions** di repo Anda. Workflow "Build APK" akan berjalan
   otomatis setiap push ke `main` (atau jalankan manual lewat
   "Run workflow").
3. Setelah selesai (sekitar 3-5 menit), buka hasil run tsb, lalu unduh
   artifact **AIAgen-debug-apk** — isinya `app-debug.apk` yang sudah bisa
   langsung diinstal di HP Android (sudah ditandatangani otomatis dengan
   debug key, cukup untuk dipakai sendiri).

## Cara build lewat Android Studio (alternatif)

Buka folder ini di Android Studio versi terbaru → biarkan Android Studio
membuat Gradle wrapper otomatis saat sinkronisasi → Run ke HP/emulator,
atau Build > Build Bundle(s)/APK(s) > Build APK(s).

## Mengubah slot akun

Di layar utama aplikasi: tekan lama kartu slot mana pun untuk mengganti
layanan, nama slot, atau URL-nya. Tekan singkat untuk membuka slot tsb
dan login (hanya perlu sekali, sesi tersimpan otomatis).

## Catatan

- Default URL tiap layanan ada di `ProfileStore.kt` (`SERVICES`) — ubah
  atau sesuaikan dari dalam aplikasi kalau URL default kurang tepat
  (terutama untuk "Flow").
- Untuk build **release** (ditandatangani dengan keystore sendiri, bukan
  debug key), tambahkan konfigurasi signing sendiri di
  `app/build.gradle.kts` dan ubah step workflow menjadi
  `gradle assembleRelease`.
