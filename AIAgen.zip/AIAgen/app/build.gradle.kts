import java.util.Base64

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------
// Kunci tanda tangan TETAP.
// Tanpa ini setiap build di GitHub Actions memakai kunci debug acak yang
// berbeda, sehingga APK baru tidak bisa menimpa APK lama dan harus uninstall
// (data login hilang). Dengan kunci tetap, APK baru langsung menimpa yang lama
// dan seluruh data (sesi login) tetap ada.
// Kunci disimpan sebagai teks base64 (aiagen-keystore.b64) agar aman diunggah
// lewat cara apa pun, lalu dibuka saat build.
// ---------------------------------------------------------------------------
val keystoreB64 = file("aiagen-keystore.b64")
val keystoreOut = layout.buildDirectory.file("signing/aiagen.keystore").get().asFile
val hasFixedKey = keystoreB64.exists()
if (hasFixedKey) {
    keystoreOut.parentFile.mkdirs()
    keystoreOut.writeBytes(Base64.getMimeDecoder().decode(keystoreB64.readText().trim()))
} else {
    logger.warn("PERINGATAN: aiagen-keystore.b64 tidak ditemukan. APK memakai kunci debug acak dan TIDAK bisa menimpa versi lama.")
}

android {
    namespace = "com.aiagen.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aiagen.app"
        minSdk = 26
        targetSdk = 34
        // versionCode naik otomatis di setiap build GitHub (nomor run), supaya
        // selalu dianggap update oleh Android.
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "2.8"
    }

    signingConfigs {
        if (hasFixedKey) {
            create("fixed") {
                storeFile = keystoreOut
                storePassword = "7FXZUfvHiBI43uNjLUbm"
                keyAlias = "aiagen"
                keyPassword = "7FXZUfvHiBI43uNjLUbm"
            }
        }
    }

    buildTypes {
        debug {
            if (hasFixedKey) signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            if (hasFixedKey) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    // Profil WebView terisolasi (slot tanpa batas)
    implementation("androidx.webkit:webkit:1.12.1")
}
