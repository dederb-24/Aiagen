package com.aiagen.app

import androidx.webkit.WebViewFeature
import androidx.webkit.ProfileStore as WebProfileStore

/**
 * Slot 1..100 memakai proses Android terpisah (lihat AndroidManifest) sehingga
 * bisa tetap hidup di latar belakang dan login lama tetap utuh.
 * Slot 101 dan seterusnya memakai fitur Profil WebView
 * (androidx.webkit): tiap slot punya cookie/localStorage/IndexedDB sendiri
 * dalam satu proses, jadi jumlah slot tidak dibatasi.
 */
object DynamicProfiles {
    const val LEGACY_SLOTS = 100

    fun name(slot: Int): String = "slot$slot"

    fun supported(): Boolean = try {
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    } catch (e: Exception) {
        false
    }

    /** Menghapus seluruh data (login, cache) milik slot dinamis. */
    fun wipe(slot: Int) {
        if (!supported()) return
        val n = name(slot)
        try {
            val store = WebProfileStore.getInstance()
            if (store.getProfile(n) == null) return
            try {
                store.deleteProfile(n)
            } catch (e: Exception) {
                // masih dipakai WebView lain -> kosongkan isinya saja
                store.getProfile(n)?.let {
                    it.cookieManager.removeAllCookies(null)
                    it.cookieManager.flush()
                    it.webStorage.deleteAllData()
                }
            }
        } catch (e: Exception) {
            // abaikan
        }
    }
}

/** Layar slot ke-21 dst. Berjalan di proses utama dengan profil WebView sendiri. */
class ProfileActivityDynamic : ProfileActivityBase() {
    override val slot: Int get() = intent.getIntExtra("slot", 0)
    override val profileName: String? get() = DynamicProfiles.name(slot)
}
