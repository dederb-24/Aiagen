package com.aiagen.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Handler

data class RunningSlot(val slot: Int, val pid: Int, val pssKb: Int, val importance: Int)

/** Daftar & kontrol slot yang sedang berjalan (tiap slot = satu proses ":slotN"). */
object RunningSlots {
    const val ACTION_STOP = "com.aiagen.app.STOP_SLOT"

    fun list(ctx: Context): List<RunningSlot> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val procs = try {
            am.runningAppProcesses
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        val prefix = ctx.packageName + ":slot"
        val mine = procs.filter { it.processName.startsWith(prefix) }
        if (mine.isEmpty()) return emptyList()
        val mem = try {
            am.getProcessMemoryInfo(mine.map { it.pid }.toIntArray())
        } catch (e: Exception) {
            null
        }
        val out = ArrayList<RunningSlot>()
        mine.forEachIndexed { i, p ->
            val n = p.processName.removePrefix(prefix).toIntOrNull() ?: return@forEachIndexed
            out.add(RunningSlot(n, p.pid, mem?.getOrNull(i)?.totalPss ?: 0, p.importance))
        }
        return out.sortedBy { it.slot }
    }

    /**
     * Mematikan satu slot: minta layarnya menutup diri (status halaman tersimpan),
     * lalu pastikan prosesnya mati supaya memori benar-benar bebas.
     */
    fun stop(ctx: Context, slot: Int, pid: Int, handler: Handler) {
        ctx.sendBroadcast(Intent(ACTION_STOP).setPackage(ctx.packageName).putExtra("slot", slot))
        handler.postDelayed({
            if (list(ctx).any { it.pid == pid }) android.os.Process.killProcess(pid)
        }, 1500L)
    }
}
