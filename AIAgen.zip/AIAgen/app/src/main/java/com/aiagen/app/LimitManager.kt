package com.aiagen.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/** Mengatur status Limit/Terbuka, hitung mundur, dan notifikasi saat slot terbuka lagi. */
object LimitManager {
    private const val CHANNEL = "limit_ready"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Slot terbuka kembali", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun remainingMs(p: Profile): Long =
        if (p.limited && p.limitEndAt > 0L) maxOf(0L, p.limitEndAt - System.currentTimeMillis()) else 0L

    /** 0..1000, makin kecil makin habis. */
    fun progress(p: Profile): Int {
        if (p.limitTotalMs <= 0L) return 0
        return ((remainingMs(p) * 1000L) / p.limitTotalMs).toInt().coerceIn(0, 1000)
    }

    fun format(ms: Long): String {
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) {
            "${h}j ${m.toString().padStart(2, '0')}m lagi"
        } else {
            "${m}m ${s.toString().padStart(2, '0')}d lagi"
        }
    }

    private fun pending(ctx: Context, slot: Int): PendingIntent {
        val i = Intent(ctx, LimitReceiver::class.java).putExtra("slot", slot)
        return PendingIntent.getBroadcast(
            ctx, slot, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun setLimit(ctx: Context, p: Profile, durationMs: Long) {
        p.limited = true
        p.limitTotalMs = durationMs
        p.limitEndAt = System.currentTimeMillis() + durationMs
        schedule(ctx, p)
    }

    fun clear(ctx: Context, p: Profile) {
        p.limited = false
        p.limitEndAt = 0L
        p.limitTotalMs = 0L
        cancel(ctx, p.slot)
    }

    fun schedule(ctx: Context, p: Profile) {
        if (!p.limited || p.limitEndAt <= 0L) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, p.slot)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, p.limitEndAt, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, p.limitEndAt, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, p.limitEndAt, pi)
        }
    }

    fun cancel(ctx: Context, slot: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, slot))
    }

    /** Membuka kembali slot yang waktunya sudah habis. True jika ada yang berubah. */
    fun sweepExpired(profiles: List<Profile>): Boolean {
        val now = System.currentTimeMillis()
        var changed = false
        for (p in profiles) {
            if (p.limited && p.limitEndAt in 1..now) {
                p.limited = false
                p.limitEndAt = 0L
                p.limitTotalMs = 0L
                changed = true
            }
        }
        return changed
    }

    fun notifyReady(ctx: Context, p: Profile) {
        ensureChannel(ctx)
        val open = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            ctx, 1000 + p.slot, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${p.label} sudah terbuka")
            .setContentText("Limit selesai. Slot siap dipakai lagi.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(2000 + p.slot, n)
    }
}

class LimitReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val slot = intent.getIntExtra("slot", 0)
        val profiles = ProfileStore.load(ctx)
        val p = profiles.firstOrNull { it.slot == slot } ?: return
        if (p.limited && p.limitEndAt <= System.currentTimeMillis() + 5000L) {
            LimitManager.clear(ctx, p)
            ProfileStore.save(ctx, profiles)
            LimitManager.notifyReady(ctx, p)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val profiles = ProfileStore.load(ctx)
        var changed = false
        for (p in profiles) {
            if (!p.limited) continue
            if (p.limitEndAt in 1..System.currentTimeMillis()) {
                LimitManager.clear(ctx, p)
                LimitManager.notifyReady(ctx, p)
                changed = true
            } else {
                LimitManager.schedule(ctx, p)
            }
        }
        if (changed) ProfileStore.save(ctx, profiles)
    }
}
