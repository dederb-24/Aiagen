package com.aiagen.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Ikon platform diambil dari ikon situsnya (favicon), disimpan di penyimpanan
 * aplikasi supaya tidak diunduh ulang. Selama belum ada, dipakai lingkaran
 * berwarna dengan huruf pertama nama platform.
 */
object IconLoader {
    private val memory = ConcurrentHashMap<String, Bitmap>()

    private fun oval(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        return d
    }

    private fun parse(hex: String): Int = try {
        Color.parseColor(hex)
    } catch (e: Exception) {
        Color.GRAY
    }

    private fun showImage(box: FrameLayout, letter: TextView, image: ImageView, bmp: Bitmap) {
        box.background = oval(Color.parseColor("#F1F2F7"))
        letter.visibility = View.GONE
        image.setImageBitmap(bmp)
        image.visibility = View.VISIBLE
    }

    /** Dipanggil saat alamat platform berubah agar ikon diambil ulang. */
    fun invalidate(ctx: Context, key: String) {
        memory.remove(key)
        File(ctx.filesDir, "icon_$key.png").delete()
    }

    fun bind(box: FrameLayout, letter: TextView, image: ImageView, platform: Platform) {
        val appCtx = box.context.applicationContext
        val key = platform.key
        val tagValue = key + "|" + platform.url
        box.tag = tagValue
        val cached = memory[key]
        if (cached != null) {
            showImage(box, letter, image, cached)
            return
        }
        letter.text = platform.name.take(1).uppercase()
        letter.visibility = View.VISIBLE
        image.visibility = View.GONE
        box.background = oval(parse(platform.color))

        val url = platform.url
        Thread {
            val bmp = loadBitmap(appCtx, key, url)
            if (bmp != null) {
                memory[key] = bmp
                box.post {
                    if (box.tag == tagValue) showImage(box, letter, image, bmp)
                }
            }
        }.start()
    }

    private fun loadBitmap(ctx: Context, key: String, siteUrl: String): Bitmap? {
        val host: String? = try {
            Uri.parse(siteUrl).host
        } catch (e: Exception) {
            null
        }
        if (host == null) return null
        val file = File(ctx.filesDir, "icon_$key.png")
        try {
            if (file.exists()) {
                val b = BitmapFactory.decodeFile(file.absolutePath)
                if (b != null) return b
            }
            val conn = URL("https://www.google.com/s2/favicons?domain=$host&sz=128")
                .openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it) }
            conn.disconnect()
            if (bmp != null) {
                file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            return bmp
        } catch (e: Exception) {
            return null
        }
    }
}
