package com.aiagen.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Ikon tiap layanan AI diambil dari ikon situs resminya (favicon), disimpan
 * di penyimpanan aplikasi supaya tidak diunduh ulang. Selama belum ada,
 * dipakai lingkaran berwarna khas layanan dengan huruf pertama.
 */
object IconLoader {
    private val domains = mapOf(
        "gemini" to "gemini.google.com",
        "claude" to "claude.ai",
        "gpt" to "chatgpt.com",
        "flow" to "labs.google",
    )
    private val colors = mapOf(
        "gemini" to Color.parseColor("#4285F4"),
        "claude" to Color.parseColor("#D97757"),
        "gpt" to Color.parseColor("#10A37F"),
        "flow" to Color.parseColor("#7C4DFF"),
    )
    private val memory = ConcurrentHashMap<String, Bitmap>()

    private fun oval(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        return d
    }

    private fun showImage(box: FrameLayout, letter: TextView, image: ImageView, bmp: Bitmap) {
        box.background = oval(Color.parseColor("#F1F2F7"))
        letter.visibility = View.GONE
        image.setImageBitmap(bmp)
        image.visibility = View.VISIBLE
    }

    fun bind(box: FrameLayout, letter: TextView, image: ImageView, key: String, name: String) {
        val appCtx = box.context.applicationContext
        box.tag = key
        val cached = memory[key]
        if (cached != null) {
            showImage(box, letter, image, cached)
            return
        }
        letter.text = name.take(1).uppercase()
        letter.visibility = View.VISIBLE
        image.visibility = View.GONE
        box.background = oval(colors[key] ?: Color.GRAY)

        Thread {
            val bmp = loadBitmap(appCtx, key)
            if (bmp != null) {
                memory[key] = bmp
                box.post {
                    if (box.tag == key) showImage(box, letter, image, bmp)
                }
            }
        }.start()
    }

    private fun loadBitmap(ctx: Context, key: String): Bitmap? {
        val domain = domains[key] ?: return null
        val file = File(ctx.filesDir, "icon_$key.png")
        try {
            if (file.exists()) {
                val b = BitmapFactory.decodeFile(file.absolutePath)
                if (b != null) return b
            }
            val conn = URL("https://www.google.com/s2/favicons?domain=$domain&sz=128")
                .openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it) }
            conn.disconnect()
            if (bmp != null) {
                file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            return bmp
        } catch (e: Exception) {
            return null
        }
    }
}
