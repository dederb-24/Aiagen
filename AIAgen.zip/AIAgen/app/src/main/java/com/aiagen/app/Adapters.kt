package com.aiagen.app

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

sealed class Row {
    data class Group(val platform: Platform, val open: Int, val total: Int) : Row()
    data class SlotRow(val profile: Profile, val platform: Platform) : Row()
    data class Next(val profile: Profile) : Row()
}

private const val TICK = "tick"
private val GREEN = Color.parseColor("#3B6D11")
private val RED = Color.parseColor("#A32D2D")

private fun colorOf(hex: String): Int = try {
    Color.parseColor(hex)
} catch (e: Exception) {
    Color.GRAY
}

class GroupVH(v: View) : RecyclerView.ViewHolder(v) {
    val bar: View = v.findViewById(R.id.groupBar)
    val name: TextView = v.findViewById(R.id.textGroup)
    val count: TextView = v.findViewById(R.id.textGroupCount)
}

class SlotVH(v: View) : RecyclerView.ViewHolder(v) {
    val iconBox: FrameLayout = v.findViewById(R.id.iconBox)
    val letter: TextView = v.findViewById(R.id.textLetter)
    val image: ImageView = v.findViewById(R.id.imageIcon)
    val label: TextView = v.findViewById(R.id.textLabel)
    val preview: TextView = v.findViewById(R.id.textPreview)
    val note: TextView = v.findViewById(R.id.textNote)
    val state: MaterialSwitch = v.findViewById(R.id.switchState)
    val stateText: TextView = v.findViewById(R.id.textState)
    val limitBox: LinearLayout = v.findViewById(R.id.limitBox)
    val bar: ProgressBar = v.findViewById(R.id.barCountdown)
    val remaining: TextView = v.findViewById(R.id.textRemaining)
}

class NextVH(v: View) : RecyclerView.ViewHolder(v) {
    val name: TextView = v.findViewById(R.id.textNextName)
    val time: TextView = v.findViewById(R.id.textNextTime)
    val bar: ProgressBar = v.findViewById(R.id.barNext)
}

class SlotAdapter(
    private val onOpen: (Profile) -> Unit,
    private val onEdit: (Profile) -> Unit,
    private val onToggle: (Profile, Boolean) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<Row> = emptyList()
    private var previews: Map<Int, Preview> = emptyMap()
    private var hidePreview = false

    fun submit(newRows: List<Row>, newPreviews: Map<Int, Preview>, hide: Boolean) {
        rows = newRows
        previews = newPreviews
        hidePreview = hide
        notifyDataSetChanged()
    }

    /** Memperbarui bar dan sisa waktu pada item yang terlihat, tanpa menggambar ulang semuanya. */
    fun tick(rv: RecyclerView) {
        val lm = rv.layoutManager as? LinearLayoutManager ?: return
        val first = lm.findFirstVisibleItemPosition()
        val last = lm.findLastVisibleItemPosition()
        if (first < 0) return
        for (i in first..last) {
            val r = rows.getOrNull(i)
            if ((r is Row.SlotRow && r.profile.limited) || r is Row.Next) notifyItemChanged(i, TICK)
        }
    }

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Group -> 0
        is Row.SlotRow -> 1
        is Row.Next -> 2
    }

    override fun getItemCount(): Int = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> GroupVH(inflater.inflate(R.layout.item_group, parent, false))
            1 -> SlotVH(inflater.inflate(R.layout.item_slot, parent, false))
            else -> NextVH(inflater.inflate(R.layout.item_next, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val r = rows[position]
        if (r is Row.Group && holder is GroupVH) {
            holder.name.text = r.platform.name
            holder.count.text = "${r.open} dari ${r.total} terbuka"
            holder.bar.setBackgroundColor(colorOf(r.platform.color))
        } else if (r is Row.SlotRow && holder is SlotVH) {
            bindSlot(holder, r)
        } else if (r is Row.Next && holder is NextVH) {
            bindNext(holder, r.profile)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads[0] == TICK) {
            val r = rows[position]
            if (r is Row.SlotRow && holder is SlotVH) {
                bindCountdown(holder, r.profile)
            } else if (r is Row.Next && holder is NextVH) {
                bindNext(holder, r.profile)
            }
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    private fun bindSlot(h: SlotVH, r: Row.SlotRow) {
        val p = r.profile
        h.label.text = p.label
        IconLoader.bind(h.iconBox, h.letter, h.image, r.platform)

        val pv = previews[p.slot]
        h.preview.text = when {
            hidePreview -> "Pratinjau disembunyikan"
            pv != null && pv.snippet.isNotBlank() -> pv.snippet
            pv != null && pv.title.isNotBlank() -> pv.title
            else -> "Belum ada chat"
        }

        if (p.note.isNotBlank()) {
            h.note.text = "Catatan: ${p.note}"
            h.note.visibility = View.VISIBLE
        } else {
            h.note.visibility = View.GONE
        }

        h.state.isChecked = !p.limited
        h.stateText.text = if (p.limited) "Limit" else "Terbuka"
        h.stateText.setTextColor(if (p.limited) RED else GREEN)
        h.state.setOnClickListener { onToggle(p, h.state.isChecked) }
        h.itemView.setOnClickListener { onOpen(p) }
        h.itemView.setOnLongClickListener {
            onEdit(p)
            true
        }
        bindCountdown(h, p)
    }

    private fun bindCountdown(h: SlotVH, p: Profile) {
        if (p.limited) {
            h.limitBox.visibility = View.VISIBLE
            h.bar.progress = LimitManager.progress(p)
            h.remaining.text = LimitManager.format(LimitManager.remainingMs(p))
        } else {
            h.limitBox.visibility = View.GONE
        }
    }

    private fun bindNext(h: NextVH, p: Profile) {
        h.name.text = p.label
        h.bar.progress = LimitManager.progress(p)
        h.time.text = LimitManager.format(LimitManager.remainingMs(p))
    }
}

class TimerAdapter(private val onOpenNow: (Profile) -> Unit) :
    RecyclerView.Adapter<TimerAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.textTimerName)
        val left: TextView = v.findViewById(R.id.textTimerLeft)
        val bar: ProgressBar = v.findViewById(R.id.barTimer)
        val button: MaterialButton = v.findViewById(R.id.buttonOpenNow)
    }

    private var items: List<Profile> = emptyList()

    fun submit(list: List<Profile>) {
        items = list
        notifyDataSetChanged()
    }

    fun tick() {
        if (items.isNotEmpty()) notifyItemRangeChanged(0, items.size, TICK)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_timer, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.name.text = p.label
        holder.button.setOnClickListener { onOpenNow(p) }
        bindTime(holder, p)
    }

    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads[0] == TICK) {
            bindTime(holder, items[position])
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    private fun bindTime(h: VH, p: Profile) {
        h.bar.progress = LimitManager.progress(p)
        h.left.text = LimitManager.format(LimitManager.remainingMs(p))
    }
}
