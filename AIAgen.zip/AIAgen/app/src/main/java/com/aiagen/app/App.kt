package com.aiagen.app

import android.app.Application
import android.os.Build
import android.webkit.WebView

/**
 * Setiap slot akun (ProfileActivity1..7) berjalan di proses Android
 * terpisah (lihat AndroidManifest: android:process=":slot1" dst).
 *
 * Secara default, semua WebView dalam SATU aplikasi berbagi direktori
 * data yang sama -> kalau dipakai dari beberapa proses sekaligus akan
 * crash ("using WebView from more than one process"). Baris di bawah
 * ini memberi setiap proses direktori datanya sendiri, sehingga cookie,
 * localStorage, dan IndexedDB-nya BENAR-BENAR terpisah antar slot --
 * persis seperti profil/profile terpisah di browser desktop.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        DownloadCenter.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val processName = currentProcessName() ?: return
            val suffix = processName.substringAfterLast(':', processName)
            if (suffix.isNotBlank()) {
                WebView.setDataDirectorySuffix(suffix)
            }
        }
    }

    private fun currentProcessName(): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Application.getProcessName()
        } else null
    }
}
