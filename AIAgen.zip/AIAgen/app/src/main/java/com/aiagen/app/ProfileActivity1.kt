package com.aiagen.app

/** Slot 1 -- berjalan di proses Android terpisah (lihat AndroidManifest). */
class ProfileActivity1 : ProfileActivityBase() {
    override val slot: Int = 1
}
