package com.aiagen.app

import android.Manifest
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Catatan & notifikasi unduhan. Unduhan dijalankan di proses slot masing-masing,
 * sedangkan tab "Unduhan" dibaca di proses utama, jadi catatannya disimpan sebagai
 * file kecil per unduhan di filesDir/downloads (aman lintas proses).
 */
object DownloadCenter {
    const val CHANNEL = "downloads"
    const val RUNNING = 0
    const val DONE = 1
    const val FAILED = 2
    private const val KEEP = 100
    private const val STALE_MS = 120_000L

    class Item(val id: String, var slot: Int, var name: String, var mime: String) {
        @Volatile var status = RUNNING
        @Volatile var done = 0L
        @Volatile var total = -1L
        @Volatile var uri: String? = null
        @Volatile var error: String? = null
        @Volatile var time = System.currentTimeMillis()
        @Volatile var lastPush = 0L
    }

    private fun dir(ctx: Context): File = File(ctx.filesDir, "downloads").also { it.mkdirs() }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Unduhan", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    // ---------- catatan ----------

    private fun write(ctx: Context, it: Item) {
        try {
            val o = JSONObject()
                .put("id", it.id).put("slot", it.slot).put("name", it.name).put("mime", it.mime)
                .put("status", it.status).put("done", it.done).put("total", it.total)
                .put("uri", it.uri ?: JSONObject.NULL).put("error", it.error ?: JSONObject.NULL)
                .put("time", it.time)
            val tmp = File(dir(ctx), it.id + ".tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(File(dir(ctx), it.id + ".json"))) {
                File(dir(ctx), it.id + ".json").writeText(o.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            // abaikan
        }
    }

    fun readAll(ctx: Context): List<Item> {
        val now = System.currentTimeMillis()
        val out = ArrayList<Item>()
        dir(ctx).listFiles { f -> f.name.endsWith(".json") }?.forEach { f ->
            try {
                val o = JSONObject(f.readText())
                val it = Item(o.getString("id"), o.optInt("slot"), o.optString("name"), o.optString("mime"))
                it.status = o.optInt("status")
                it.done = o.optLong("done")
                it.total = o.optLong("total", -1L)
                it.uri = if (o.isNull("uri")) null else o.optString("uri")
                it.error = if (o.isNull("error")) null else o.optString("error")
                it.time = o.optLong("time")
                // Proses slot dimatikan di tengah jalan -> catatan tidak pernah selesai
                if (it.status == RUNNING && now - f.lastModified() > STALE_MS) {
                    it.status = FAILED
                    it.error = "terhenti"
                }
                out.add(it)
            } catch (e: Exception) {
                // catatan rusak: abaikan
            }
        }
        return out.sortedByDescending { it.time }
    }

    fun remove(ctx: Context, id: String) {
        File(dir(ctx), "$id.json").delete()
        try {
            NotificationManagerCompat.from(ctx).cancel(notifId(id))
        } catch (e: Exception) {
            // abaikan
        }
    }

    fun clearFinished(ctx: Context) {
        readAll(ctx).filter { it.status != RUNNING }.forEach { remove(ctx, it.id) }
    }

    private fun prune(ctx: Context) {
        val all = readAll(ctx)
        if (all.size > KEEP) all.drop(KEEP).filter { it.status != RUNNING }.forEach { remove(ctx, it.id) }
    }

    // ---------- siklus unduhan ----------

    fun start(ctx: Context, slot: Int, name: String, mime: String): Item {
        val item = Item(UUID.randomUUID().toString(), slot, name, mime)
        write(ctx, item)
        notify(ctx, item)
        prune(ctx)
        return item
    }

    /** Dipanggil sering saat menulis; notifikasi & catatan diperbarui paling cepat tiap 400 ms. */
    fun progress(ctx: Context, item: Item, done: Long, total: Long) {
        item.done = done
        if (total > 0) item.total = total
        val now = System.currentTimeMillis()
        if (now - item.lastPush < 400L) return
        item.lastPush = now
        write(ctx, item)
        notify(ctx, item)
    }

    fun finish(ctx: Context, item: Item, uri: Uri?, size: Long) {
        item.status = DONE
        item.uri = uri?.toString()
        item.done = size
        item.total = size
        item.time = System.currentTimeMillis()
        write(ctx, item)
        notify(ctx, item)
    }

    fun fail(ctx: Context, item: Item?, reason: String) {
        if (item == null) return
        item.status = FAILED
        item.error = reason
        write(ctx, item)
        notify(ctx, item)
    }

    // ---------- notifikasi ----------

    private fun notifId(id: String) = 5000 + (id.hashCode() and 0xFFFFF)

    private fun fmt(b: Long): String = when {
        b >= 1_048_576L -> String.format("%.1f MB", b / 1_048_576.0)
        b >= 1024L -> String.format("%.0f KB", b / 1024.0)
        else -> "$b B"
    }

    fun openIntent(ctx: Context, item: Item): Intent {
        val u = item.uri
        return if (item.status == DONE && u != null) {
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(u), item.mime.ifBlank { "*/*" })
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun notify(ctx: Context, item: Item) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) return

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val id = notifId(item.id)
            val b = NotificationCompat.Builder(ctx, CHANNEL)
                .setContentTitle(item.name.ifBlank { "Unduhan" })
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)

            when (item.status) {
                RUNNING -> {
                    b.setSmallIcon(android.R.drawable.stat_sys_download)
                        .setOngoing(true)
                    if (item.total > 0) {
                        val pct = ((item.done * 100) / item.total).toInt().coerceIn(0, 100)
                        b.setProgress(100, pct, false)
                            .setContentText("$pct% · ${fmt(item.done)} / ${fmt(item.total)}")
                    } else {
                        b.setProgress(0, 0, true)
                            .setContentText(if (item.done > 0) "Mengunduh · ${fmt(item.done)}" else "Menyiapkan…")
                    }
                    val main = Intent(ctx, MainActivity::class.java)
                        .putExtra("open_page", 4)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    b.setContentIntent(PendingIntent.getActivity(ctx, id, main, flags))
                }
                DONE -> {
                    b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                        .setContentText("Selesai · ${fmt(item.total)} · ketuk untuk membuka")
                        .setAutoCancel(true)
                        .setProgress(0, 0, false)
                    b.setContentIntent(PendingIntent.getActivity(ctx, id, openIntent(ctx, item), flags))
                }
                else -> {
                    b.setSmallIcon(android.R.drawable.stat_notify_error)
                        .setContentText("Gagal: ${item.error ?: "tidak diketahui"}")
                        .setAutoCancel(true)
                        .setProgress(0, 0, false)
                    val main = Intent(ctx, MainActivity::class.java)
                        .putExtra("open_page", 4)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    b.setContentIntent(PendingIntent.getActivity(ctx, id, main, flags))
                }
            }
            NotificationManagerCompat.from(ctx).notify(id, b.build())
        } catch (e: Exception) {
            // notifikasi gagal tidak boleh menggagalkan unduhan
        }
    }
}

/** OutputStream pembungkus yang melaporkan jumlah byte yang sudah tertulis. */
class CountingOutputStream(
    private val out: java.io.OutputStream,
    private val onCount: (Long) -> Unit
) : java.io.OutputStream() {
    private var n = 0L
    override fun write(b: Int) {
        out.write(b)
        n++
        onCount(n)
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        out.write(b, off, len)
        n += len
        onCount(n)
    }

    override fun flush() = out.flush()
    override fun close() = out.close()
}
