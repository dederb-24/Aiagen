package com.aiagen.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Platform AI (bawaan atau custom buatan pengguna). */
data class Platform(
    val key: String,
    var name: String,
    var url: String,
    var color: String,
    var defaultLimitMin: Int,
    var hidden: Boolean = false,
    val builtin: Boolean = false
)

data class Profile(
    var slot: Int,
    var serviceKey: String,
    var label: String,
    var url: String,
    var inUse: Boolean = false,
    var limited: Boolean = false,
    var limitEndAt: Long = 0L,
    var limitTotalMs: Long = 0L,
    var note: String = ""
)

object PlatformStore {
    private const val PREFS = "ai_agen_platforms"
    private const val KEY = "platforms_json"

    val COLOR_NAMES = listOf("Biru", "Hijau", "Oranye", "Ungu", "Merah", "Pink", "Teal", "Abu-abu")
    val COLOR_HEX = listOf("#4285F4", "#10A37F", "#E8833A", "#7C4DFF", "#E24B4A", "#D4537E", "#1D9E75", "#5F5E5A")

    fun defaults(): MutableList<Platform> = mutableListOf(
        Platform("claude", "Claude", "https://claude.ai", "#D97757", 300, false, true),
        Platform("flow", "Flow", "https://labs.google/flow", "#7C4DFF", 1440, false, true),
        Platform("gemini", "Gemini", "https://gemini.google.com/app", "#4285F4", 1440, false, true),
        Platform("gpt", "ChatGPT", "https://chatgpt.com", "#10A37F", 180, false, true),
    )

    fun load(ctx: Context): MutableList<Platform> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        val list = mutableListOf<Platform>()
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Platform(
                            key = o.getString("key"),
                            name = o.getString("name"),
                            url = o.getString("url"),
                            color = o.optString("color", "#5F5E5A"),
                            defaultLimitMin = o.optInt("defaultLimitMin", 60),
                            hidden = o.optBoolean("hidden", false),
                            builtin = o.optBoolean("builtin", false)
                        )
                    )
                }
            } catch (e: Exception) {
                list.clear()
            }
        }
        // pastikan platform bawaan selalu ada
        for (d in defaults()) {
            if (list.none { it.key == d.key }) list.add(d)
        }
        return list
    }

    fun save(ctx: Context, list: List<Platform>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject().put("key", p.key).put("name", p.name).put("url", p.url)
                    .put("color", p.color).put("defaultLimitMin", p.defaultLimitMin)
                    .put("hidden", p.hidden).put("builtin", p.builtin)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun newKey(): String = "custom_" + System.currentTimeMillis()
}

/** Pengaturan sederhana aplikasi. */
object AppSettings {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("ai_agen_settings", Context.MODE_PRIVATE)
    fun hidePreview(ctx: Context): Boolean = sp(ctx).getBoolean("hide_preview", false)
    fun setHidePreview(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_preview", v).apply()
    fun lockEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("lock_enabled", false)
    fun setLockEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("lock_enabled", v).apply()
}

/**
 * Menyimpan konfigurasi slot (platform apa, nama, URL, status limit).
 * Ini HANYA konfigurasi, bukan kredensial -- login tetap dilakukan manual
 * oleh pengguna di dalam WebView tiap slot, dan sesi (cookie) disimpan
 * Android per-proses lewat App.kt.
 */
object ProfileStore {
    private const val PREFS = "ai_agen_profiles"
    private const val KEY = "profiles_json"
    const val MAX_SLOTS = DynamicProfiles.LEGACY_SLOTS // slot berbasis proses; di atasnya tanpa batas

    private val ACTIVITIES: List<Class<*>> = listOf(
        ProfileActivity1::class.java,
        ProfileActivity2::class.java,
        ProfileActivity3::class.java,
        ProfileActivity4::class.java,
        ProfileActivity5::class.java,
        ProfileActivity6::class.java,
        ProfileActivity7::class.java,
        ProfileActivity8::class.java,
        ProfileActivity9::class.java,
        ProfileActivity10::class.java,
        ProfileActivity11::class.java,
        ProfileActivity12::class.java,
        ProfileActivity13::class.java,
        ProfileActivity14::class.java,
        ProfileActivity15::class.java,
        ProfileActivity16::class.java,
        ProfileActivity17::class.java,
        ProfileActivity18::class.java,
        ProfileActivity19::class.java,
        ProfileActivity20::class.java
    )

    fun load(ctx: Context): MutableList<Profile> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                val list = mutableListOf<Profile>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Profile(
                            slot = o.getInt("slot"),
                            serviceKey = o.getString("serviceKey"),
                            label = o.getString("label"),
                            url = o.getString("url"),
                            inUse = o.optBoolean("inUse", false),
                            limited = o.optBoolean("limited", false),
                            limitEndAt = o.optLong("limitEndAt", 0L),
                            limitTotalMs = o.optLong("limitTotalMs", 0L),
                            note = o.optString("note", "")
                        )
                    )
                }
                if (list.isNotEmpty()) return list.sortedBy { it.slot }.toMutableList()
            } catch (e: Exception) {
                // data rusak -> pakai default
            }
        }
        return defaultProfiles(PlatformStore.load(ctx))
    }

    fun save(ctx: Context, profiles: List<Profile>) {
        val arr = JSONArray()
        for (p in profiles) {
            arr.put(
                JSONObject().put("slot", p.slot).put("serviceKey", p.serviceKey).put("label", p.label)
                    .put("url", p.url).put("inUse", p.inUse).put("limited", p.limited)
                    .put("limitEndAt", p.limitEndAt).put("limitTotalMs", p.limitTotalMs).put("note", p.note)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    /**
     * Nama slot otomatis: "<Platform> <nomor>", nomornya lanjutan dari nomor
     * terbesar yang sudah dipakai platform yang sama (slot [exclude] diabaikan).
     */
    fun nextLabel(profiles: List<Profile>, platform: Platform, exclude: Profile?): String {
        val re = Regex("^" + Regex.escape(platform.name) + " (\\d+)$")
        val maxN = profiles
            .filter { it !== exclude }
            .mapNotNull { re.find(it.label.trim())?.groupValues?.get(1)?.toIntOrNull() }
            .maxOrNull() ?: 0
        return "${platform.name} ${maxN + 1}"
    }

    /** Menambah slot baru dengan nomor terkecil yang masih kosong. Tanpa batas jumlah. */
    fun addSlot(profiles: MutableList<Profile>, platform: Platform): Profile? {
        val used = profiles.map { it.slot }.toHashSet()
        var id = 1
        while (id in used) id++
        val p = Profile(
            slot = id,
            serviceKey = platform.key,
            label = nextLabel(profiles, platform, null),
            url = platform.url
        )
        profiles.add(p)
        profiles.sortBy { it.slot }
        return p
    }

    private fun defaultProfiles(platforms: List<Platform>): MutableList<Profile> {
        val order = listOf("claude", "claude", "gpt", "gpt", "gemini", "gemini", "flow")
        val list = mutableListOf<Profile>()
        order.forEachIndexed { idx, key ->
            val pl = platforms.first { it.key == key }
            list.add(
                Profile(
                    slot = idx + 1,
                    serviceKey = key,
                    label = nextLabel(list, pl, null),
                    url = pl.url
                )
            )
        }
        return list
    }

    fun activityClassFor(slot: Int): Class<*> =
        if (slot in 1..ACTIVITIES.size) ACTIVITIES[slot - 1] else ProfileActivityDynamic::class.java
}
