package com.aiagen.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Service(val key: String, val label: String, val defaultUrl: String)

val SERVICES = listOf(
    Service("gemini", "Gemini", "https://gemini.google.com/app"),
    Service("claude", "Claude", "https://claude.ai"),
    Service("gpt", "ChatGPT", "https://chatgpt.com"),
    Service("flow", "Flow", "https://labs.google/flow"),
)

data class Profile(
    var slot: Int,
    var serviceKey: String,
    var label: String,
    var url: String,
    var inUse: Boolean = false
)

/**
 * Menyimpan konfigurasi 7 slot (layanan apa, label buatan user, URL).
 * Ini HANYA menyimpan konfigurasi, bukan kredensial -- login tetap
 * dilakukan manual oleh pengguna di dalam WebView masing-masing slot,
 * dan sesi (cookie) disimpan oleh Android sendiri per-proses lewat
 * App.kt, bukan oleh kelas ini.
 */
object ProfileStore {
    private const val PREFS = "ai_agen_profiles"
    private const val KEY = "profiles_json"
    const val DEFAULT_SLOTS = 7
    const val MAX_SLOTS = 20

    private val ACTIVITIES: List<Class<*>> = listOf(
        ProfileActivity1::class.java,
        ProfileActivity2::class.java,
        ProfileActivity3::class.java,
        ProfileActivity4::class.java,
        ProfileActivity5::class.java,
        ProfileActivity6::class.java,
        ProfileActivity7::class.java,
        ProfileActivity8::class.java,
        ProfileActivity9::class.java,
        ProfileActivity10::class.java,
        ProfileActivity11::class.java,
        ProfileActivity12::class.java,
        ProfileActivity13::class.java,
        ProfileActivity14::class.java,
        ProfileActivity15::class.java,
        ProfileActivity16::class.java,
        ProfileActivity17::class.java,
        ProfileActivity18::class.java,
        ProfileActivity19::class.java,
        ProfileActivity20::class.java
    )

    fun load(ctx: Context): MutableList<Profile> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                val list = mutableListOf<Profile>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Profile(
                            slot = o.getInt("slot"),
                            serviceKey = o.getString("serviceKey"),
                            label = o.getString("label"),
                            url = o.getString("url"),
                            inUse = o.optBoolean("inUse", false)
                        )
                    )
                }
                if (list.isNotEmpty()) return list.sortedBy { it.slot }.toMutableList()
            } catch (e: Exception) {
                // data rusak -> pakai default
            }
        }
        return defaultProfiles()
    }

    fun save(ctx: Context, profiles: List<Profile>) {
        val arr = JSONArray()
        for (p in profiles) {
            val o = JSONObject()
            o.put("slot", p.slot)
            o.put("serviceKey", p.serviceKey)
            o.put("label", p.label)
            o.put("url", p.url)
            o.put("inUse", p.inUse)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    /**
     * Nama slot otomatis: "<Layanan> <nomor>", nomornya lanjutan dari nomor
     * terbesar yang sudah dipakai layanan yang sama (slot [exclude] diabaikan).
     */
    fun nextLabel(profiles: List<Profile>, svc: Service, exclude: Profile?): String {
        val re = Regex("^" + Regex.escape(svc.label) + " (\\d+)$")
        val maxN = profiles
            .filter { it !== exclude }
            .mapNotNull { re.find(it.label.trim())?.groupValues?.get(1)?.toIntOrNull() }
            .maxOrNull() ?: 0
        return "${svc.label} ${maxN + 1}"
    }

    /** Menambah slot baru dengan nomor terkecil yang masih kosong. Null jika sudah penuh. */
    fun addSlot(profiles: MutableList<Profile>): Profile? {
        val id = (1..MAX_SLOTS).firstOrNull { n -> profiles.none { it.slot == n } } ?: return null
        val svc = SERVICES.first()
        val p = Profile(
            slot = id,
            serviceKey = svc.key,
            label = nextLabel(profiles, svc, null),
            url = svc.defaultUrl,
            inUse = false
        )
        profiles.add(p)
        profiles.sortBy { it.slot }
        return p
    }

    private fun defaultProfiles(): MutableList<Profile> {
        val defaults = listOf("claude", "claude", "gpt", "gpt", "gemini", "gemini", "flow")
        return defaults.mapIndexed { idx, key ->
            val svc = SERVICES.first { it.key == key }
            Profile(
                slot = idx + 1,
                serviceKey = key,
                label = "${svc.label} ${idx + 1}",
                url = svc.defaultUrl,
                inUse = false
            )
        }.toMutableList()
    }

    fun activityClassFor(slot: Int): Class<*> =
        ACTIVITIES.getOrNull(slot - 1) ?: throw IllegalArgumentException("slot tidak valid: $slot")
}
