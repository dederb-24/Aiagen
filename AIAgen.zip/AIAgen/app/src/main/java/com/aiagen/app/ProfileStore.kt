package com.aiagen.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Service(val key: String, val label: String, val defaultUrl: String)

val SERVICES = listOf(
    Service("gemini", "Gemini", "https://gemini.google.com/app"),
    Service("claude", "Claude", "https://claude.ai"),
    Service("gpt", "ChatGPT", "https://chatgpt.com"),
    Service("flow", "Flow", "https://labs.google/flow"),
)

data class Profile(
    var slot: Int,
    var serviceKey: String,
    var label: String,
    var url: String,
    var inUse: Boolean = false
)

/**
 * Menyimpan konfigurasi 7 slot (layanan apa, label buatan user, URL).
 * Ini HANYA menyimpan konfigurasi, bukan kredensial -- login tetap
 * dilakukan manual oleh pengguna di dalam WebView masing-masing slot,
 * dan sesi (cookie) disimpan oleh Android sendiri per-proses lewat
 * App.kt, bukan oleh kelas ini.
 */
object ProfileStore {
    private const val PREFS = "ai_agen_profiles"
    private const val KEY = "profiles_json"
    const val SLOT_COUNT = 7

    fun load(ctx: Context): MutableList<Profile> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw != null) {
            val arr = JSONArray(raw)
            val list = mutableListOf<Profile>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Profile(
                        slot = o.getInt("slot"),
                        serviceKey = o.getString("serviceKey"),
                        label = o.getString("label"),
                        url = o.getString("url"),
                        inUse = o.optBoolean("inUse", false)
                    )
                )
            }
            if (list.size == SLOT_COUNT) return list
        }
        return defaultProfiles()
    }

    fun save(ctx: Context, profiles: List<Profile>) {
        val arr = JSONArray()
        for (p in profiles) {
            val o = JSONObject()
            o.put("slot", p.slot)
            o.put("serviceKey", p.serviceKey)
            o.put("label", p.label)
            o.put("url", p.url)
            o.put("inUse", p.inUse)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    private fun defaultProfiles(): MutableList<Profile> {
        // 7 slot default: isi bebas, bisa diedit user di aplikasi
        val defaults = listOf("claude", "claude", "gpt", "gpt", "gemini", "gemini", "flow")
        return defaults.mapIndexed { idx, key ->
            val svc = SERVICES.first { it.key == key }
            Profile(
                slot = idx + 1,
                serviceKey = key,
                label = "${svc.label} ${idx + 1}",
                url = svc.defaultUrl,
                inUse = false
            )
        }.toMutableList()
    }

    fun activityClassFor(slot: Int): Class<*> = when (slot) {
        1 -> ProfileActivity1::class.java
        2 -> ProfileActivity2::class.java
        3 -> ProfileActivity3::class.java
        4 -> ProfileActivity4::class.java
        5 -> ProfileActivity5::class.java
        6 -> ProfileActivity6::class.java
        7 -> ProfileActivity7::class.java
        else -> throw IllegalArgumentException("slot tidak valid: $slot")
    }
}
