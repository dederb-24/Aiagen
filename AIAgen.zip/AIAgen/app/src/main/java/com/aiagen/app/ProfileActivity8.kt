package com.aiagen.app

/** Slot 8 -- berjalan di proses Android terpisah (lihat AndroidManifest). */
class ProfileActivity8 : ProfileActivityBase() {
    override val slot: Int = 8
}
