package com.aiagen.app

import android.content.Context
import org.json.JSONObject
import java.io.File

data class Preview(val title: String, val snippet: String, val time: Long)

/**
 * Pratinjau chat terakhir per slot. Ditulis oleh proses slot (saat kamu
 * keluar dari slot) dan dibaca oleh layar utama. Disimpan sebagai berkas
 * di penyimpanan aplikasi, hanya di HP ini.
 */
object PreviewStore {
    private fun file(ctx: Context, slot: Int) = File(ctx.filesDir, "preview_$slot.json")

    fun save(ctx: Context, slot: Int, title: String, snippet: String) {
        try {
            val o = JSONObject().put("title", title).put("snippet", snippet).put("time", System.currentTimeMillis())
            file(ctx, slot).writeText(o.toString())
        } catch (e: Exception) {
            // abaikan
        }
    }

    fun load(ctx: Context, slot: Int): Preview? {
        return try {
            val f = file(ctx, slot)
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            Preview(o.optString("title"), o.optString("snippet"), o.optLong("time"))
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context, slot: Int) {
        file(ctx, slot).delete()
    }
}
