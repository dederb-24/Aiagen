package com.aiagen.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Parcelable
import android.provider.MediaStore
import android.view.View
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.appbar.MaterialToolbar
import java.io.File
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Dasar untuk layar satu slot akun. Dipakai oleh ProfileActivity1..20 yang
 * masing-masing berjalan di proses Android terpisah (lihat App.kt).
 *
 * Nama slot dan URL dikirim lewat Intent dari MainActivity, supaya slot yang
 * baru ditambah tetap terbaca walaupun prosesnya sudah berjalan sebelumnya.
 */
abstract class ProfileActivityBase : AppCompatActivity() {

    abstract val slot: Int
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private var startUrl: String = "https://claude.ai"

    // ----- pemilih file (lampiran) + kamera -----
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingParams: WebChromeClient.FileChooserParams? = null
    private var pendingCameraFile: File? = null
    private var pendingCameraUri: Uri? = null

    // ----- izin mikrofon/kamera untuk situs -----
    private var pendingWebRequest: PermissionRequest? = null
    private var pendingWebNeeded: List<String> = emptyList()
    private val allowedKeys = mutableSetOf<String>()

    // ----- izin lokasi untuk situs -----
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val cb = filePathCallback
            filePathCallback = null
            var uris: Array<Uri>? =
                WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            val camFile = pendingCameraFile
            val camUri = pendingCameraUri
            pendingCameraFile = null
            pendingCameraUri = null
            if (uris == null && res.resultCode == RESULT_OK && camFile != null && camUri != null &&
                camFile.exists() && camFile.length() > 0L
            ) {
                uris = arrayOf(camUri)
            }
            cb?.onReceiveValue(uris)
        }

    private val chooserCameraPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val p = pendingParams
            pendingParams = null
            if (p != null) openFileChooser(p, granted)
        }

    private val webPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            finishWebPermission()
        }

    private val geoPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            finishGeo(result.values.any { it })
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mode hapus: bersihkan sesi slot ini (di prosesnya sendiri), lalu tutup
        if (intent.getBooleanExtra("wipe", false)) {
            clearSession(null)
            finish()
            return
        }

        setContentView(R.layout.activity_profile)

        val label = intent.getStringExtra("label") ?: "Slot $slot"
        startUrl = intent.getStringExtra("url") ?: "https://claude.ai"

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = label
        toolbar.setNavigationOnClickListener { finish() }
        progress = findViewById(R.id.progress)
        webView = findViewById(R.id.webView)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)

        toolbar.inflateMenu(R.menu.profile_menu)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_reload -> {
                    webView.reload()
                    true
                }
                R.id.action_home -> {
                    webView.loadUrl(startUrl)
                    true
                }
                R.id.action_copy -> {
                    copyLink()
                    true
                }
                R.id.action_browser -> {
                    openInBrowser()
                    true
                }
                R.id.action_logout -> {
                    confirmLogout()
                    true
                }
                else -> false
            }
        }

        btnBack.setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        btnForward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        findViewById<ImageButton>(R.id.btnReload).setOnClickListener { webView.reload() }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { webView.loadUrl(startUrl) }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val scheme = u.scheme ?: return false
                if (scheme in INTERNAL_SCHEMES) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                    // tidak ada aplikasi yang bisa membuka
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                updateNav()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                updateNav()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // Lampiran file / foto dari HP
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (params == null) return false
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                if (hasPermission(Manifest.permission.CAMERA)) {
                    openFileChooser(params, true)
                } else {
                    pendingParams = params
                    chooserCameraPermLauncher.launch(Manifest.permission.CAMERA)
                }
                return true
            }

            // Mikrofon dan kamera (suara, panggilan video, dll.)
            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                handleWebPermission(request)
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest?) {
                if (request != null && request == pendingWebRequest) pendingWebRequest = null
            }

            // Lokasi / navigasi peta
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (origin == null || callback == null) return
                if (!origin.startsWith("https://")) {
                    callback.invoke(origin, false, false)
                    return
                }
                AlertDialog.Builder(this@ProfileActivityBase)
                    .setTitle("Izin lokasi")
                    .setMessage("Izinkan $origin mengakses lokasi kamu?")
                    .setPositiveButton("Izinkan") { _, _ -> askLocation(origin, callback) }
                    .setNegativeButton("Tolak") { _, _ -> callback.invoke(origin, false, false) }
                    .setOnCancelListener { callback.invoke(origin, false, false) }
                    .show()
            }
        }

        // Unduhan dari situs disimpan ke folder Download di HP
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            if (!url.startsWith("http")) {
                Toast.makeText(this, "Jenis unduhan ini belum didukung", Toast.LENGTH_SHORT).show()
                return@setDownloadListener
            }
            try {
                val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val req = DownloadManager.Request(Uri.parse(url))
                req.setMimeType(mimeType)
                req.addRequestHeader("User-Agent", userAgent)
                val cookie = CookieManager.getInstance().getCookie(url)
                if (cookie != null) req.addRequestHeader("Cookie", cookie)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Mengunduh $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal mengunduh file", Toast.LENGTH_SHORT).show()
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl(startUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }
        updateNav()
    }

    // ---------- navigasi ----------

    private fun updateNav() {
        if (!::webView.isInitialized) return
        btnBack.alpha = if (webView.canGoBack()) 1f else 0.35f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.35f
        val host = webView.url?.let { Uri.parse(it).host }
        toolbar.subtitle = host
    }

    private fun copyLink() {
        val url = webView.url
        if (url == null) {
            Toast.makeText(this, "Belum ada halaman", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", url))
        Toast.makeText(this, "Link disalin", Toast.LENGTH_SHORT).show()
    }

    private fun openInBrowser() {
        val url = webView.url ?: startUrl
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- izin ----------

    private fun hasPermission(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun androidPermFor(res: String): String? = when (res) {
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        else -> null
    }

    private fun handleWebPermission(request: PermissionRequest) {
        val needed = request.resources.filter {
            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
        }
        val origin = request.origin
        if (needed.isEmpty() || origin.scheme != "https") {
            request.deny()
            return
        }
        val host = origin.host ?: ""
        val key = host + "|" + needed.sorted().joinToString(",")
        if (allowedKeys.contains(key)) {
            proceedWebPermission(request, needed)
            return
        }
        val what = needed.joinToString(" dan ") {
            if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) "mikrofon" else "kamera"
        }
        AlertDialog.Builder(this)
            .setTitle("Izin akses")
            .setMessage("Izinkan $host memakai $what?")
            .setPositiveButton("Izinkan") { _, _ ->
                allowedKeys.add(key)
                proceedWebPermission(request, needed)
            }
            .setNegativeButton("Tolak") { _, _ -> request.deny() }
            .setOnCancelListener { request.deny() }
            .show()
    }

    private fun proceedWebPermission(request: PermissionRequest, needed: List<String>) {
        val missing = needed.mapNotNull { androidPermFor(it) }.filter { !hasPermission(it) }
        if (missing.isEmpty()) {
            request.grant(needed.toTypedArray())
            return
        }
        pendingWebRequest?.deny()
        pendingWebRequest = request
        pendingWebNeeded = needed
        webPermLauncher.launch(missing.toTypedArray())
    }

    private fun finishWebPermission() {
        val req = pendingWebRequest ?: return
        pendingWebRequest = null
        val granted = pendingWebNeeded.filter { r ->
            val p = androidPermFor(r)
            p != null && hasPermission(p)
        }
        if (granted.isEmpty()) req.deny() else req.grant(granted.toTypedArray())
    }

    private fun askLocation(origin: String, callback: GeolocationPermissions.Callback) {
        if (hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        ) {
            callback.invoke(origin, true, false)
            return
        }
        geoOrigin = origin
        geoCallback = callback
        geoPermLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    }

    private fun finishGeo(granted: Boolean) {
        val o = geoOrigin
        val c = geoCallback
        geoOrigin = null
        geoCallback = null
        if (o != null && c != null) c.invoke(o, granted, false)
    }

    // ---------- pemilih file + kamera ----------

    private fun openFileChooser(params: WebChromeClient.FileChooserParams, withCamera: Boolean) {
        try {
            val chooser = Intent.createChooser(params.createIntent(), "Pilih file")
            val types = params.acceptTypes
            val wantsImage = types.isEmpty() || types.any { it.isBlank() || it.startsWith("image") }
            pendingCameraFile = null
            pendingCameraUri = null
            if (withCamera && wantsImage) {
                val dir = File(cacheDir, "camera")
                dir.mkdirs()
                val f = File(dir, "foto_${System.currentTimeMillis()}.jpg")
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val cam = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                cam.putExtra(MediaStore.EXTRA_OUTPUT, uri)
                cam.clipData = ClipData.newRawUri("", uri)
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf<Parcelable>(cam))
                pendingCameraFile = f
                pendingCameraUri = uri
            }
            fileLauncher.launch(chooser)
        } catch (e: Exception) {
            val cb = filePathCallback
            filePathCallback = null
            cb?.onReceiveValue(null)
            Toast.makeText(this, "Tidak bisa membuka pemilih file", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- sesi ----------

    private fun clearSession(w: WebView?) {
        val cm = CookieManager.getInstance()
        cm.removeAllCookies(null)
        cm.flush()
        WebStorage.getInstance().deleteAllData()
        if (w != null) {
            w.clearCache(true)
            w.clearHistory()
            w.clearFormData()
        } else {
            val tmp = WebView(this)
            tmp.clearCache(true)
            tmp.clearHistory()
            tmp.clearFormData()
            tmp.destroy()
        }
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this)
            .setTitle("Keluar dari akun?")
            .setMessage("Sesi login di slot ini akan dihapus. Kamu perlu login lagi nanti.")
            .setPositiveButton("Keluar") { _, _ ->
                clearSession(webView)
                PreviewStore.delete(this, slot)
                webView.loadUrl(startUrl)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        capturePreview()
    }

    /** Mengambil judul chat dan teks terakhir yang terlihat, untuk pratinjau di layar utama. */
    private fun capturePreview() {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript(PREVIEW_JS) { raw -> savePreview(raw) }
    }

    private fun savePreview(raw: String?) {
        if (raw == null || raw == "null") return
        try {
            val inner = JSONTokener(raw).nextValue() as? String ?: return
            if (inner.isBlank()) return
            val o = JSONObject(inner)
            val title = o.optString("title")
            val snippet = o.optString("snippet")
            if (title.isNotBlank() || snippet.isNotBlank()) {
                PreviewStore.save(this, slot, title, snippet)
            }
        } catch (e: Exception) {
            // abaikan
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::webView.isInitialized) webView.saveState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    companion object {
        private val INTERNAL_SCHEMES = setOf("http", "https", "about", "blob", "data", "javascript", "file")

        private val PREVIEW_JS = """
            (function(){try{
              var t=(document.title||'').trim();
              var root=document.querySelector('main')||document.body;
              var raw=((root&&root.innerText)||'').split('\n');
              var lines=raw.map(function(s){return s.trim();}).filter(function(s){return s.length>=25;});
              var bad=/(dapat membuat kesalahan|can make mistakes|terms|privacy|kebijakan|syarat|cookie|log in|sign up|masuk|daftar)/i;
              var good=lines.filter(function(s){return !bad.test(s);});
              var last=good.length?good[good.length-1]:'';
              return JSON.stringify({title:t,snippet:last.slice(0,160)});
            }catch(e){return '';}})()
        """.trimIndent()
    }
}
