package com.aiagen.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Parcel
import android.os.Parcelable
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.appbar.MaterialToolbar
import java.io.BufferedInputStream
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Dasar untuk layar satu slot akun. Dipakai oleh ProfileActivity1..20 yang
 * masing-masing berjalan di proses Android terpisah (lihat App.kt).
 *
 * Nama slot dan URL dikirim lewat Intent dari MainActivity, supaya slot yang
 * baru ditambah tetap terbaca walaupun prosesnya sudah berjalan sebelumnya.
 */
abstract class ProfileActivityBase : AppCompatActivity() {

    abstract val slot: Int

    /** Nama profil WebView terisolasi (slot dinamis). Null = slot lama berbasis proses. */
    protected open val profileName: String? get() = null
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private var startUrl: String = "https://claude.ai"

    // ----- pemilih file (lampiran) + kamera -----
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingParams: WebChromeClient.FileChooserParams? = null
    private var pendingCameraFile: File? = null
    private var pendingCameraUri: Uri? = null

    // ----- izin mikrofon/kamera untuk situs -----
    private var pendingWebRequest: PermissionRequest? = null
    private var pendingWebNeeded: List<String> = emptyList()
    private val allowedKeys = mutableSetOf<String>()

    // ----- izin lokasi untuk situs -----
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val cb = filePathCallback
            filePathCallback = null
            var uris: Array<Uri>? =
                WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            val camFile = pendingCameraFile
            val camUri = pendingCameraUri
            pendingCameraFile = null
            pendingCameraUri = null
            if (uris == null && res.resultCode == RESULT_OK && camFile != null && camUri != null &&
                camFile.exists() && camFile.length() > 0L
            ) {
                uris = arrayOf(camUri)
            }
            cb?.onReceiveValue(uris)
        }

    private val chooserCameraPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val p = pendingParams
            pendingParams = null
            if (p != null) openFileChooser(p, granted)
        }

    private val webPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            finishWebPermission()
        }

    private val geoPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            finishGeo(result.values.any { it })
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mode hapus: bersihkan sesi slot ini (di prosesnya sendiri), lalu tutup
        if (intent.getBooleanExtra("wipe", false)) {
            clearSession(null)
            finish()
            return
        }

        setContentView(R.layout.activity_profile)

        val label = intent.getStringExtra("label") ?: "Slot $slot"
        startUrl = intent.getStringExtra("url") ?: "https://claude.ai"

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = label
        toolbar.setNavigationOnClickListener { finish() }
        progress = findViewById(R.id.progress)
        webView = findViewById(R.id.webView)

        // Slot dinamis: pasang profil WebView sendiri SEBELUM WebView dipakai apa pun
        val pn = profileName
        if (pn != null) {
            if (slot <= 0 || !DynamicProfiles.supported()) {
                Toast.makeText(
                    this,
                    "Slot di atas ${DynamicProfiles.LEGACY_SLOTS} butuh Android System WebView versi terbaru. Perbarui lewat Play Store.",
                    Toast.LENGTH_LONG
                ).show()
                finish()
                return
            }
            try {
                androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(pn)
                androidx.webkit.WebViewCompat.setProfile(webView, pn)
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membuka profil slot", Toast.LENGTH_LONG).show()
                finish()
                return
            }
        }
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)

        toolbar.inflateMenu(R.menu.profile_menu)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_reload -> {
                    webView.reload()
                    true
                }
                R.id.action_home -> {
                    webView.loadUrl(startUrl)
                    true
                }
                R.id.action_copy -> {
                    copyLink()
                    true
                }
                R.id.action_browser -> {
                    openInBrowser()
                    true
                }
                R.id.action_logout -> {
                    confirmLogout()
                    true
                }
                else -> false
            }
        }

        btnBack.setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        btnForward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        findViewById<ImageButton>(R.id.btnReload).setOnClickListener { webView.reload() }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { webView.loadUrl(startUrl) }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
        }

        // Cookie login harus diterima (termasuk pihak ketiga, dipakai "Masuk dengan Google")
        cookies().setAcceptCookie(true)
        cookies().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val scheme = u.scheme ?: return false
                if (scheme in INTERNAL_SCHEMES) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                    // tidak ada aplikasi yang bisa membuka
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                view?.evaluateJavascript(DOWNLOAD_HOOK_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(DOWNLOAD_HOOK_JS, null)
                updateNav()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                updateNav()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // Lampiran file / foto dari HP
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (params == null) return false
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                if (hasPermission(Manifest.permission.CAMERA)) {
                    openFileChooser(params, true)
                } else {
                    pendingParams = params
                    chooserCameraPermLauncher.launch(Manifest.permission.CAMERA)
                }
                return true
            }

            // Mikrofon dan kamera (suara, panggilan video, dll.)
            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                handleWebPermission(request)
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest?) {
                if (request != null && request == pendingWebRequest) pendingWebRequest = null
            }

            // Lokasi / navigasi peta
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (origin == null || callback == null) return
                if (!origin.startsWith("https://")) {
                    callback.invoke(origin, false, false)
                    return
                }
                AlertDialog.Builder(this@ProfileActivityBase)
                    .setTitle("Izin lokasi")
                    .setMessage("Izinkan $origin mengakses lokasi kamu?")
                    .setPositiveButton("Izinkan") { _, _ -> askLocation(origin, callback) }
                    .setNegativeButton("Tolak") { _, _ -> callback.invoke(origin, false, false) }
                    .setOnCancelListener { callback.invoke(origin, false, false) }
                    .show()
            }
        }

        // Unduhan dari situs disimpan ke folder Download di HP
        webView.addJavascriptInterface(DownloadBridge(), "AiaDl")
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val name = fixFileName(URLUtil.guessFileName(url, contentDisposition, mimeType), mimeType)
            when {
                url.startsWith("blob:") -> downloadBlob(url, name, mimeType)
                url.startsWith("data:") -> downloadDataUrl(url, name, mimeType)
                url.startsWith("http") -> downloadHttp(url, userAgent, name, mimeType)
                else -> Toast.makeText(this, "Jenis unduhan ini belum didukung", Toast.LENGTH_SHORT).show()
            }
        }

        if (savedInstanceState == null) {
            // Lanjutkan percakapan terakhir; kalau tidak ada, mulai dari halaman awal
            if (!restoreWebState()) webView.loadUrl(startUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }
        updateNav()
    }

    // ---------- lanjutkan percakapan terakhir ----------

    private fun stateFile() = File(filesDir, "webstate_$slot.bin")

    // Menyimpan riwayat halaman WebView (URL percakapan terakhir + posisi) ke file,
    // supaya saat slot dibuka lagi tidak mulai dari awal.
    private fun saveWebState() {
        if (!::webView.isInitialized) return
        val url = webView.url
        if (url.isNullOrEmpty() || url.startsWith("about:")) return
        val p = Parcel.obtain()
        try {
            val b = Bundle()
            val list = webView.saveState(b) ?: return
            if (list.size == 0) return
            p.writeString(startUrl)
            p.writeBundle(b)
            val tmp = File(filesDir, "webstate_$slot.tmp")
            tmp.writeBytes(p.marshall())
            if (!tmp.renameTo(stateFile())) {
                stateFile().writeBytes(tmp.readBytes())
                tmp.delete()
            }
        } catch (e: Exception) {
            // abaikan, cukup mulai dari awal lain kali
        } finally {
            p.recycle()
        }
    }

    private fun restoreWebState(): Boolean {
        val f = stateFile()
        if (!f.exists()) return false
        val p = Parcel.obtain()
        return try {
            val bytes = f.readBytes()
            p.unmarshall(bytes, 0, bytes.size)
            p.setDataPosition(0)
            // Abaikan jika platform/URL awal slot ini sudah diganti
            if (p.readString() != startUrl) return false
            val b = p.readBundle(WebView::class.java.classLoader) ?: return false
            webView.restoreState(b) != null
        } catch (e: Exception) {
            false
        } finally {
            p.recycle()
        }
    }

    // ---------- unduhan blob: / data: ----------

    // Token sekali pakai, supaya hanya unduhan yang kita mulai sendiri yang
    // bisa menulis file lewat jembatan JavaScript (bukan skrip situs sembarang).
    private val pendingDownloads = mutableMapOf<String, Pair<String, String>>()

    private fun downloadBlob(url: String, guessed: String, mime: String?) {
        val token = UUID.randomUUID().toString()
        pendingDownloads[token] = Pair(guessed, mime ?: "application/octet-stream")
        // Pakai Blob yang sudah disimpan oleh hook (URL blob: sering langsung dicabut situs),
        // kalau tidak ada baru diambil lewat XHR.
        val js = DOWNLOAD_BLOB_JS
            .replace("__URL__", JSONObject.quote(url))
            .replace("__TOKEN__", JSONObject.quote(token))
        webView.evaluateJavascript(js, null)
        Toast.makeText(this, "Mengunduh…", Toast.LENGTH_SHORT).show()
    }

    // Ganti ekstensi .bin dengan ekstensi yang sesuai tipe file, bila tipenya diketahui.
    private fun fixFileName(name: String, mime: String?): String {
        if (!name.endsWith(".bin", ignoreCase = true)) return name
        val m = mime?.substringBefore(';')?.trim()?.lowercase()
        if (m.isNullOrEmpty() || m == "application/octet-stream") return name
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(m) ?: return name
        return name.dropLast(4) + "." + ext
    }

    private fun downloadDataUrl(url: String, name: String, mime: String?) {
        try {
            val comma = url.indexOf(',')
            val header = url.substring(0, comma)
            val body = url.substring(comma + 1)
            val bytes = if (header.contains(";base64")) {
                Base64.decode(body, Base64.DEFAULT)
            } else {
                Uri.decode(body).toByteArray(Charsets.UTF_8)
            }
            saveToDownloads(name, mime ?: "application/octet-stream", bytes)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal mengunduh file", Toast.LENGTH_SHORT).show()
        }
    }

    // Menebak ekstensi dari isi file (magic bytes), untuk file yang dikirim sebagai octet-stream.
    private fun sniffExt(b: ByteArray): String? {
        fun at(o: Int, t: String): Boolean =
            b.size >= o + t.length && t.indices.all { b[o + it] == t[it].code.toByte() }
        fun u(i: Int): Int = if (i < b.size) b[i].toInt() and 0xFF else -1
        return when {
            at(4, "ftyp") -> {
                val brand = if (b.size >= 12) String(b, 8, 4, Charsets.ISO_8859_1) else ""
                when {
                    brand.startsWith("qt") -> "mov"
                    brand.startsWith("M4A") -> "m4a"
                    brand.startsWith("3g") -> "3gp"
                    brand.startsWith("heic") || brand.startsWith("heix") || brand.startsWith("mif1") -> "heic"
                    brand.startsWith("avif") -> "avif"
                    else -> "mp4"
                }
            }
            u(0) == 0x89 && at(1, "PNG") -> "png"
            u(0) == 0xFF && u(1) == 0xD8 && u(2) == 0xFF -> "jpg"
            at(0, "GIF8") -> "gif"
            at(0, "RIFF") && at(8, "WEBP") -> "webp"
            at(0, "RIFF") && at(8, "WAVE") -> "wav"
            at(0, "RIFF") && at(8, "AVI ") -> "avi"
            at(0, "%PDF") -> "pdf"
            at(0, "PK") && u(2) == 3 && u(3) == 4 -> "zip"
            at(0, "ID3") || (u(0) == 0xFF && (u(1) and 0xE0) == 0xE0) -> "mp3"
            at(0, "OggS") -> "ogg"
            at(0, "fLaC") -> "flac"
            u(0) == 0x1A && u(1) == 0x45 && u(2) == 0xDF && u(3) == 0xA3 -> "webm"
            else -> null
        }
    }

    private fun saveToDownloads(rawName: String, rawMime: String, bytes: ByteArray) {
        saveStream(rawName, rawMime, bytes.copyOf(minOf(bytes.size, 64))) { it.write(bytes) }
    }

    // Unduhan http(s) dengan cookie sesi, disimpan lewat jalur yang sama
    // supaya ekstensi bisa ditentukan dari isi file.
    private fun downloadHttp(url: String, userAgent: String?, guessed: String, mime: String?) {
        Toast.makeText(this, "Mengunduh $guessed", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                if (userAgent != null) conn.setRequestProperty("User-Agent", userAgent)
                cookies().getCookie(url)?.let { conn.setRequestProperty("Cookie", it) }
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 30000
                conn.readTimeout = 60000
                if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                val type = (mime ?: conn.contentType ?: "application/octet-stream").substringBefore(';').trim()
                val input = BufferedInputStream(conn.inputStream, 64 * 1024)
                input.use { ins ->
                    ins.mark(64)
                    val buf = ByteArray(64)
                    val n = ins.read(buf).coerceAtLeast(0)
                    ins.reset()
                    saveStream(guessed, type, buf.copyOf(n)) { out -> ins.copyTo(out) }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Gagal mengunduh file", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    // Menyimpan ke folder Download. "head" = byte awal file, dipakai untuk menebak ekstensi.
    private fun saveStream(rawName: String, rawMime: String, head: ByteArray, write: (OutputStream) -> Unit) {
        var name = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        var mime = rawMime
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty() || ext == "bin" || mime == "application/octet-stream") {
            val found = sniffExt(head)
            if (found != null) {
                if (ext.isEmpty() || ext == "bin") name = name.substringBeforeLast('.') + "." + found
                MimeTypeMap.getSingleton().getMimeTypeFromExtension(found)?.let { mime = it }
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("insert gagal")
                contentResolver.openOutputStream(uri)?.use { write(it) }
                    ?: throw IllegalStateException("stream gagal")
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                File(dir, name).outputStream().use { write(it) }
            }
            runOnUiThread { Toast.makeText(this, "Tersimpan di Download: $name ($mime)", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_SHORT).show() }
        }
    }

    inner class DownloadBridge {
        @JavascriptInterface
        fun save(token: String, realName: String, realMime: String, base64: String) {
            val info = pendingDownloads.remove(token) ?: return
            val bytes = try {
                Base64.decode(base64, Base64.DEFAULT)
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@ProfileActivityBase, "Gagal mengunduh file", Toast.LENGTH_SHORT).show()
                }
                return
            }
            val mime = if (realMime.isNotBlank()) realMime else info.second
            val name = if (realName.isNotBlank()) realName else fixFileName(info.first, mime)
            Thread { saveToDownloads(name, mime, bytes) }.start()
        }

        @JavascriptInterface
        fun fail(token: String) {
            pendingDownloads.remove(token)
            runOnUiThread {
                Toast.makeText(this@ProfileActivityBase, "Gagal mengunduh file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- navigasi ----------

    private fun updateNav() {
        if (!::webView.isInitialized) return
        btnBack.alpha = if (webView.canGoBack()) 1f else 0.35f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.35f
        val host = webView.url?.let { Uri.parse(it).host }
        toolbar.subtitle = host
    }

    private fun copyLink() {
        val url = webView.url
        if (url == null) {
            Toast.makeText(this, "Belum ada halaman", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", url))
        Toast.makeText(this, "Link disalin", Toast.LENGTH_SHORT).show()
    }

    private fun openInBrowser() {
        val url = webView.url ?: startUrl
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- izin ----------

    private fun hasPermission(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun androidPermFor(res: String): String? = when (res) {
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        else -> null
    }

    private fun handleWebPermission(request: PermissionRequest) {
        val needed = request.resources.filter {
            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
        }
        val origin = request.origin
        if (needed.isEmpty() || origin.scheme != "https") {
            request.deny()
            return
        }
        val host = origin.host ?: ""
        val key = host + "|" + needed.sorted().joinToString(",")
        if (allowedKeys.contains(key)) {
            proceedWebPermission(request, needed)
            return
        }
        val what = needed.joinToString(" dan ") {
            if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) "mikrofon" else "kamera"
        }
        AlertDialog.Builder(this)
            .setTitle("Izin akses")
            .setMessage("Izinkan $host memakai $what?")
            .setPositiveButton("Izinkan") { _, _ ->
                allowedKeys.add(key)
                proceedWebPermission(request, needed)
            }
            .setNegativeButton("Tolak") { _, _ -> request.deny() }
            .setOnCancelListener { request.deny() }
            .show()
    }

    private fun proceedWebPermission(request: PermissionRequest, needed: List<String>) {
        val missing = needed.mapNotNull { androidPermFor(it) }.filter { !hasPermission(it) }
        if (missing.isEmpty()) {
            request.grant(needed.toTypedArray())
            return
        }
        pendingWebRequest?.deny()
        pendingWebRequest = request
        pendingWebNeeded = needed
        webPermLauncher.launch(missing.toTypedArray())
    }

    private fun finishWebPermission() {
        val req = pendingWebRequest ?: return
        pendingWebRequest = null
        val granted = pendingWebNeeded.filter { r ->
            val p = androidPermFor(r)
            p != null && hasPermission(p)
        }
        if (granted.isEmpty()) req.deny() else req.grant(granted.toTypedArray())
    }

    private fun askLocation(origin: String, callback: GeolocationPermissions.Callback) {
        if (hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        ) {
            callback.invoke(origin, true, false)
            return
        }
        geoOrigin = origin
        geoCallback = callback
        geoPermLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    }

    private fun finishGeo(granted: Boolean) {
        val o = geoOrigin
        val c = geoCallback
        geoOrigin = null
        geoCallback = null
        if (o != null && c != null) c.invoke(o, granted, false)
    }

    // ---------- pemilih file + kamera ----------

    private fun openFileChooser(params: WebChromeClient.FileChooserParams, withCamera: Boolean) {
        try {
            val chooser = Intent.createChooser(params.createIntent(), "Pilih file")
            val types = params.acceptTypes
            val wantsImage = types.isEmpty() || types.any { it.isBlank() || it.startsWith("image") }
            pendingCameraFile = null
            pendingCameraUri = null
            if (withCamera && wantsImage) {
                val dir = File(cacheDir, "camera")
                dir.mkdirs()
                val f = File(dir, "foto_${System.currentTimeMillis()}.jpg")
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val cam = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                cam.putExtra(MediaStore.EXTRA_OUTPUT, uri)
                cam.clipData = ClipData.newRawUri("", uri)
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf<Parcelable>(cam))
                pendingCameraFile = f
                pendingCameraUri = uri
            }
            fileLauncher.launch(chooser)
        } catch (e: Exception) {
            val cb = filePathCallback
            filePathCallback = null
            cb?.onReceiveValue(null)
            Toast.makeText(this, "Tidak bisa membuka pemilih file", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- sesi ----------

    /** Pengelola cookie milik slot ini (profil sendiri untuk slot dinamis). */
    private fun cookies(): CookieManager {
        val pn = profileName
        if (pn != null) {
            try {
                androidx.webkit.ProfileStore.getInstance().getProfile(pn)?.let { return it.cookieManager }
            } catch (e: Exception) {
                // pakai bawaan
            }
        }
        return CookieManager.getInstance()
    }

    private fun clearSession(w: WebView?) {
        stateFile().delete()
        val cm = cookies()
        cm.removeAllCookies(null)
        cm.flush()
        val pn = profileName
        if (pn != null) {
            try {
                androidx.webkit.ProfileStore.getInstance().getProfile(pn)?.webStorage?.deleteAllData()
            } catch (e: Exception) {
                // abaikan
            }
        } else {
            WebStorage.getInstance().deleteAllData()
        }
        if (w != null) {
            w.clearCache(true)
            w.clearHistory()
            w.clearFormData()
        } else {
            val tmp = WebView(this)
            tmp.clearCache(true)
            tmp.clearHistory()
            tmp.clearFormData()
            tmp.destroy()
        }
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this)
            .setTitle("Keluar dari akun?")
            .setMessage("Sesi login di slot ini akan dihapus. Kamu perlu login lagi nanti.")
            .setPositiveButton("Keluar") { _, _ ->
                clearSession(webView)
                PreviewStore.delete(this, slot)
                webView.loadUrl(startUrl)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        // Simpan cookie ke disk supaya login tidak hilang walau aplikasi ditutup paksa
        try {
            cookies().flush()
        } catch (e: Exception) {
            // abaikan
        }
        saveWebState()
        capturePreview()
    }

    /** Mengambil judul chat dan teks terakhir yang terlihat, untuk pratinjau di layar utama. */
    private fun capturePreview() {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript(PREVIEW_JS) { raw -> savePreview(raw) }
    }

    private fun savePreview(raw: String?) {
        if (raw == null || raw == "null") return
        try {
            val inner = JSONTokener(raw).nextValue() as? String ?: return
            if (inner.isBlank()) return
            val o = JSONObject(inner)
            val title = o.optString("title")
            val snippet = o.optString("snippet")
            if (title.isNotBlank() || snippet.isNotBlank()) {
                PreviewStore.save(this, slot, title, snippet)
            }
        } catch (e: Exception) {
            // abaikan
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::webView.isInitialized) webView.saveState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    companion object {
        // Menangkap nama file asli dari <a download="..."> dan menyimpan 3 Blob terakhir
        // (URL blob: sering dicabut situs sebelum sempat dibaca).
        private const val DOWNLOAD_HOOK_JS =
            "(function(){if(window.__aiaHook)return;window.__aiaHook=1;" +
            "window.__aiaBlobs={};window.__aiaKeys=[];" +
            "var rec=function(a){try{if(a&&a.download){window.__aiaName=a.download;window.__aiaT=Date.now();}}catch(e){}};" +
            "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;rec(a);},true);" +
            "var oc=HTMLAnchorElement.prototype.click;" +
            "HTMLAnchorElement.prototype.click=function(){rec(this);return oc.apply(this,arguments);};" +
            "var cu=URL.createObjectURL;" +
            "URL.createObjectURL=function(o){var u=cu.apply(this,arguments);" +
            "try{if(o instanceof Blob){window.__aiaBlobs[u]=o;window.__aiaKeys.push(u);" +
            "while(window.__aiaKeys.length>3){delete window.__aiaBlobs[window.__aiaKeys.shift()];}}}catch(e){}return u;};})();"

        private const val DOWNLOAD_BLOB_JS =
            "(function(){var U=__URL__,T=__TOKEN__;" +
            "var rd=function(b){var r=new FileReader();r.onloadend=function(){var s=String(r.result);" +
            "var n=(window.__aiaName&&Date.now()-(window.__aiaT||0)<20000)?window.__aiaName:'';window.__aiaName='';" +
            "AiaDl.save(T,n,b.type||'',s.substring(s.indexOf(',')+1));};r.onerror=function(){AiaDl.fail(T);};r.readAsDataURL(b);};" +
            "try{var cb=window.__aiaBlobs&&window.__aiaBlobs[U];if(cb){rd(cb);return;}" +
            "var x=new XMLHttpRequest();x.open('GET',U);x.responseType='blob';" +
            "x.onload=function(){rd(x.response);};x.onerror=function(){AiaDl.fail(T);};x.send();}" +
            "catch(e){AiaDl.fail(T);}})();"

        private val INTERNAL_SCHEMES = setOf("http", "https", "about", "blob", "data", "javascript", "file")

        private val PREVIEW_JS = """
            (function(){try{
              var t=(document.title||'').trim();
              var root=document.querySelector('main')||document.body;
              var raw=((root&&root.innerText)||'').split('\n');
              var lines=raw.map(function(s){return s.trim();}).filter(function(s){return s.length>=25;});
              var bad=/(dapat membuat kesalahan|can make mistakes|terms|privacy|kebijakan|syarat|cookie|log in|sign up|masuk|daftar)/i;
              var good=lines.filter(function(s){return !bad.test(s);});
              var last=good.length?good[good.length-1]:'';
              return JSON.stringify({title:t,snippet:last.slice(0,160)});
            }catch(e){return '';}})()
        """.trimIndent()
    }
}
