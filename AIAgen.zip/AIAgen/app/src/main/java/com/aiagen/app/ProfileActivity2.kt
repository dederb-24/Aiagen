package com.aiagen.app

/** Slot 2 -- berjalan di proses Android terpisah (lihat AndroidManifest). */
class ProfileActivity2 : ProfileActivityBase() {
    override val slot: Int = 2
}
