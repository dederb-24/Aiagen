package com.aiagen.app

import android.Manifest
import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var profiles: MutableList<Profile>
    private lateinit var platforms: MutableList<Platform>
    private lateinit var slotAdapter: SlotAdapter
    private lateinit var timerAdapter: TimerAdapter
    private lateinit var recyclerSlots: RecyclerView
    private lateinit var recyclerTimer: RecyclerView
    private lateinit var pageHome: View
    private lateinit var pageTimer: View
    private lateinit var pageSettings: View
    private lateinit var pageRunning: View
    private lateinit var runningList: LinearLayout
    private lateinit var textRunningSummary: TextView
    private lateinit var textRunningEmpty: TextView
    private lateinit var btnKillAll: View
    private var runningTick = 0
    private lateinit var pageDownloads: View
    private lateinit var downloadList: LinearLayout
    private lateinit var textDownloadSummary: TextView
    private lateinit var textDownloadEmpty: TextView
    private lateinit var btnClearDownloads: View
    private lateinit var fabAdd: View
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var textSummary: TextView
    private lateinit var statOpen: TextView
    private lateinit var statLimit: TextView
    private lateinit var textTimerEmpty: TextView
    private lateinit var platformList: LinearLayout
    private lateinit var lockOverlay: View
    private lateinit var switchHidePreview: MaterialSwitch
    private lateinit var switchLock: MaterialSwitch

    private var filter = 0 // 0 semua, 1 terbuka, 2 limit
    private var query = ""
    private var page = 0
    private var previews: Map<Int, Preview> = emptyMap()
    private var unlocked = false
    private var leftAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000L)
        }
    }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val unlockLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == RESULT_OK) {
                unlocked = true
                leftAt = System.currentTimeMillis()
                lockOverlay.visibility = View.GONE
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        LimitManager.ensureChannel(this)

        platforms = PlatformStore.load(this)
        profiles = ProfileStore.load(this)

        pageHome = findViewById(R.id.pageHome)
        pageTimer = findViewById(R.id.pageTimer)
        pageSettings = findViewById(R.id.pageSettings)
        pageRunning = findViewById(R.id.pageRunning)
        pageDownloads = findViewById(R.id.pageDownloads)
        downloadList = findViewById(R.id.downloadList)
        textDownloadSummary = findViewById(R.id.textDownloadSummary)
        textDownloadEmpty = findViewById(R.id.textDownloadEmpty)
        btnClearDownloads = findViewById(R.id.btnClearDownloads)
        btnClearDownloads.setOnClickListener {
            DownloadCenter.clearFinished(this)
            renderDownloads()
        }
        runningList = findViewById(R.id.runningList)
        textRunningSummary = findViewById(R.id.textRunningSummary)
        textRunningEmpty = findViewById(R.id.textRunningEmpty)
        btnKillAll = findViewById(R.id.btnKillAll)
        btnKillAll.setOnClickListener {
            val items = RunningSlots.list(this)
            items.forEach { RunningSlots.stop(this, it.slot, it.pid, handler) }
            Toast.makeText(this, "${items.size} slot dimatikan", Toast.LENGTH_SHORT).show()
            handler.postDelayed({ if (page == 3) renderRunning() }, 1800L)
        }
        fabAdd = findViewById(R.id.fabAdd)
        bottomNav = findViewById(R.id.bottomNav)
        textSummary = findViewById(R.id.textSummary)
        try {
            val info = packageManager.getPackageInfo(packageName, 0)
            val code = androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(info)
            findViewById<TextView>(R.id.textVersion).text = "v${info.versionName} (build $code)"
        } catch (e: Exception) {
            findViewById<TextView>(R.id.textVersion).text = ""
        }
        statOpen = findViewById(R.id.statOpen)
        statLimit = findViewById(R.id.statLimit)
        textTimerEmpty = findViewById(R.id.textTimerEmpty)
        platformList = findViewById(R.id.platformList)
        lockOverlay = findViewById(R.id.lockOverlay)
        switchHidePreview = findViewById(R.id.switchHidePreview)
        switchLock = findViewById(R.id.switchLock)
        recyclerSlots = findViewById(R.id.recyclerSlots)
        recyclerTimer = findViewById(R.id.recyclerTimer)

        slotAdapter = SlotAdapter(
            onOpen = { p -> openProfile(p) },
            onEdit = { p -> showEditDialog(p) },
            onToggle = { p, wantOpen -> onToggle(p, wantOpen) }
        )
        recyclerSlots.layoutManager = LinearLayoutManager(this)
        recyclerSlots.adapter = slotAdapter
        (recyclerSlots.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        timerAdapter = TimerAdapter(onOpenNow = { p ->
            LimitManager.clear(this, p)
            persist()
            refreshAll()
        })
        recyclerTimer.layoutManager = LinearLayoutManager(this)
        recyclerTimer.adapter = timerAdapter
        (recyclerTimer.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        findViewById<ChipGroup>(R.id.chipFilter).setOnCheckedStateChangeListener { _, ids ->
            filter = when {
                ids.contains(R.id.chipOpen) -> 1
                ids.contains(R.id.chipLimit) -> 2
                else -> 0
            }
            refreshAll()
        }

        findViewById<EditText>(R.id.editSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                refreshAll()
            }
        })

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showPage(0)
                R.id.nav_running -> showPage(3)
                R.id.nav_downloads -> showPage(4)
                R.id.nav_timer -> showPage(1)
                R.id.nav_settings -> showPage(2)
            }
            true
        }

        fabAdd.setOnClickListener { addSlot() }
        findViewById<View>(R.id.buttonAddPlatform).setOnClickListener { showPlatformDialog(null) }
        findViewById<View>(R.id.buttonUnlock).setOnClickListener { requestUnlock() }

        switchHidePreview.isChecked = AppSettings.hidePreview(this)
        switchHidePreview.setOnCheckedChangeListener { _, v ->
            AppSettings.setHidePreview(this, v)
            refreshAll()
        }
        switchLock.isChecked = AppSettings.lockEnabled(this)
        switchLock.setOnCheckedChangeListener { _, v -> onLockSwitch(v) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (page != 0) {
                    bottomNav.selectedItemId = R.id.nav_home
                } else {
                    // Jangan tutup: slot yang hidup di latar belakang tetap terjaga
                    moveTaskToBack(true)
                }
            }
        })

        showPage(0)
        consumeOpenPage(intent)
        addOnNewIntentListener { consumeOpenPage(it) }
    }

    override fun onResume() {
        super.onResume()
        platforms = PlatformStore.load(this)
        profiles = ProfileStore.load(this)
        if (LimitManager.sweepExpired(profiles)) persist()
        loadPreviews()
        refreshAll()
        lockIfNeeded()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 1000L)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onStop() {
        leftAt = System.currentTimeMillis()
        super.onStop()
    }

    // ---------- data & tampilan ----------

    private fun persist() {
        ProfileStore.save(this, profiles)
    }

    private fun platformOf(p: Profile): Platform =
        platforms.firstOrNull { it.key == p.serviceKey } ?: platforms.first()

    private fun loadPreviews() {
        val map = HashMap<Int, Preview>()
        for (p in profiles) {
            val pv = PreviewStore.load(this, p.slot)
            if (pv != null) map[p.slot] = pv
        }
        previews = map
    }

    private val labelRe = Regex("^(.*?)\\s*(\\d+)?$")

    private fun naturalOrder(): Comparator<Profile> = compareBy<Profile>(
        { labelRe.find(it.label.trim())?.groupValues?.get(1)?.lowercase() ?: it.label.lowercase() },
        { labelRe.find(it.label.trim())?.groupValues?.get(2)?.toIntOrNull() ?: 0 },
        { it.slot }
    )

    private fun buildRows(): List<Row> {
        val q = query.trim().lowercase()
        val filtered = profiles.filter { p ->
            val pl = platformOf(p)
            val okFilter = when (filter) {
                1 -> !p.limited
                2 -> p.limited
                else -> true
            }
            val okQuery = q.isEmpty() ||
                p.label.lowercase().contains(q) ||
                p.note.lowercase().contains(q) ||
                pl.name.lowercase().contains(q)
            okFilter && okQuery
        }

        val rows = mutableListOf<Row>()
        val next = profiles.filter { it.limited && it.limitEndAt > 0L }.minByOrNull { it.limitEndAt }
        if (next != null && filter != 1 && q.isEmpty()) rows.add(Row.Next(next))

        val groups = filtered.groupBy { platformOf(it).key }
        val ordered = platforms.filter { groups.containsKey(it.key) }.sortedBy { it.name.lowercase() }
        for (pl in ordered) {
            val inGroup = groups[pl.key] ?: continue
            val all = profiles.filter { it.serviceKey == pl.key }
            rows.add(Row.Group(pl, all.count { !it.limited }, all.size))
            for (p in inGroup.sortedWith(naturalOrder())) rows.add(Row.SlotRow(p, pl))
        }
        return rows
    }

    private fun limitedSorted(): List<Profile> =
        profiles.filter { it.limited && it.limitEndAt > 0L }.sortedBy { it.limitEndAt }

    private fun refreshAll() {
        val total = profiles.size
        val open = profiles.count { !it.limited }
        textSummary.text = "$open dari $total slot siap dipakai"
        statOpen.text = "Terbuka  $open"
        statLimit.text = "Limit  ${total - open}"

        slotAdapter.submit(buildRows(), previews, AppSettings.hidePreview(this))

        val limited = limitedSorted()
        timerAdapter.submit(limited)
        textTimerEmpty.visibility = if (limited.isEmpty()) View.VISIBLE else View.GONE

        if (page == 2) renderPlatformList()
    }

    private fun fmtSize(b: Long): String = when {
        b >= 1_048_576L -> String.format("%.1f MB", b / 1_048_576.0)
        b >= 1024L -> String.format("%.0f KB", b / 1024.0)
        else -> "$b B"
    }

    private fun renderDownloads() {
        val items = DownloadCenter.readAll(this)
        val running = items.count { it.status == DownloadCenter.RUNNING }
        textDownloadSummary.text = when {
            items.isEmpty() -> "Belum ada unduhan"
            running > 0 -> "${items.size} unduhan · $running berjalan"
            else -> "${items.size} unduhan"
        }
        textDownloadEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        btnClearDownloads.visibility =
            if (items.any { it.status != DownloadCenter.RUNNING }) View.VISIBLE else View.GONE
        val timeFmt = java.text.SimpleDateFormat("HH:mm dd/MM", java.util.Locale.getDefault())
        downloadList.removeAllViews()
        for (d in items) {
            val v = layoutInflater.inflate(R.layout.item_download, downloadList, false)
            v.findViewById<TextView>(R.id.dlTitle).text = d.name.ifBlank { "Unduhan" }
            val bar = v.findViewById<android.widget.ProgressBar>(R.id.dlProgress)
            val sub = v.findViewById<TextView>(R.id.dlSub)
            when (d.status) {
                DownloadCenter.RUNNING -> {
                    bar.visibility = View.VISIBLE
                    if (d.total > 0) {
                        val pct = ((d.done * 100) / d.total).toInt().coerceIn(0, 100)
                        bar.isIndeterminate = false
                        bar.progress = pct
                        sub.text = "Mengunduh · $pct% · ${fmtSize(d.done)} / ${fmtSize(d.total)}"
                    } else {
                        bar.isIndeterminate = true
                        sub.text = if (d.done > 0) "Mengunduh · ${fmtSize(d.done)}" else "Menyiapkan…"
                    }
                }
                DownloadCenter.DONE -> {
                    bar.visibility = View.GONE
                    sub.text = "Selesai · ${fmtSize(d.total)} · ${timeFmt.format(java.util.Date(d.time))} · Slot ${d.slot}"
                }
                else -> {
                    bar.visibility = View.GONE
                    sub.text = "Gagal · ${d.error ?: "tidak diketahui"} · Slot ${d.slot}"
                }
            }
            v.findViewById<View>(R.id.dlRemove).setOnClickListener {
                DownloadCenter.remove(this, d.id)
                renderDownloads()
            }
            if (d.status == DownloadCenter.DONE) v.setOnClickListener { openDownload(d) }
            downloadList.addView(v)
        }
    }

    private fun openDownload(d: DownloadCenter.Item) {
        try {
            startActivity(DownloadCenter.openIntent(this, d))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini", Toast.LENGTH_SHORT).show()
        }
    }

    // Ketukan pada notifikasi unduhan membuka tab Unduhan
    private fun consumeOpenPage(i: Intent?) {
        if (i != null && i.getIntExtra("open_page", -1) == 4) {
            i.removeExtra("open_page")
            bottomNav.selectedItemId = R.id.nav_downloads
        }
    }

    private fun renderRunning() {
        val items = RunningSlots.list(this)
        val totalMb = items.sumOf { it.pssKb } / 1024
        textRunningSummary.text =
            if (items.isEmpty()) "Tidak ada slot berjalan" else "${items.size} slot berjalan · sekitar $totalMb MB"
        textRunningEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        btnKillAll.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        runningList.removeAllViews()
        for (r in items) {
            val v = layoutInflater.inflate(R.layout.item_running, runningList, false)
            val prof = profiles.firstOrNull { it.slot == r.slot }
            val plat = prof?.let { pf -> platforms.firstOrNull { it.key == pf.serviceKey }?.name }
            val state = if (r.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE) {
                "sedang dibuka"
            } else {
                "di latar belakang"
            }
            v.findViewById<TextView>(R.id.runTitle).text = prof?.label ?: "Slot ${r.slot}"
            v.findViewById<TextView>(R.id.runSub).text =
                "Slot ${r.slot}" + (plat?.let { " · $it" } ?: "") + " · ${r.pssKb / 1024} MB · $state"
            v.findViewById<View>(R.id.btnStop).setOnClickListener {
                RunningSlots.stop(this, r.slot, r.pid, handler)
                handler.postDelayed({ if (page == 3) renderRunning() }, 1800L)
            }
            if (prof != null) v.setOnClickListener { openProfile(prof) }
            runningList.addView(v)
        }
    }

    private fun onTick() {
        if (page == 3 && ++runningTick % 3 == 0) renderRunning()
        if (page == 4) renderDownloads()
        if (LimitManager.sweepExpired(profiles)) {
            persist()
            refreshAll()
        } else {
            slotAdapter.tick(recyclerSlots)
            timerAdapter.tick()
        }
    }

    private fun showPage(n: Int) {
        page = n
        pageHome.visibility = if (n == 0) View.VISIBLE else View.GONE
        pageTimer.visibility = if (n == 1) View.VISIBLE else View.GONE
        pageSettings.visibility = if (n == 2) View.VISIBLE else View.GONE
        pageRunning.visibility = if (n == 3) View.VISIBLE else View.GONE
        pageDownloads.visibility = if (n == 4) View.VISIBLE else View.GONE
        if (n == 4) renderDownloads()
        if (n == 3) renderRunning()
        fabAdd.visibility = if (n == 0) View.VISIBLE else View.GONE
        if (n == 2) renderPlatformList()
    }

    // ---------- aksi slot ----------

    private fun openProfile(p: Profile) {
        val cls = ProfileStore.activityClassFor(p.slot)
        val intent = Intent(this, cls)
            .putExtra("slot", p.slot)
            .putExtra("label", p.label)
            .putExtra("url", p.url)
        // Slot yang masih hidup di latar belakang dibawa ke depan apa adanya
        if (p.slot <= DynamicProfiles.LEGACY_SLOTS) {
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        startActivity(intent)
    }

    private fun addSlot() {
        val pl = platforms.filter { !it.hidden }.minByOrNull { it.name.lowercase() } ?: platforms.first()
        val p = ProfileStore.addSlot(profiles, pl)
        if (p == null) return
        persist()
        refreshAll()
        showEditDialog(p)
    }

    private fun confirmDelete(p: Profile) {
        AlertDialog.Builder(this)
            .setTitle("Hapus slot ${p.slot}?")
            .setMessage("Sesi login di slot ini ikut dihapus.")
            .setPositiveButton("Hapus") { _, _ ->
                try {
                    java.io.File(filesDir, "webstate_${p.slot}.bin").delete()
                    if (p.slot > DynamicProfiles.LEGACY_SLOTS) {
                        DynamicProfiles.wipe(p.slot)
                    } else {
                        // Dijalankan di proses slot itu sendiri untuk membersihkan sesinya
                        startActivity(
                            Intent(this, ProfileStore.activityClassFor(p.slot)).putExtra("wipe", true)
                        )
                    }
                } catch (e: Exception) {
                    // abaikan
                }
                LimitManager.cancel(this, p.slot)
                PreviewStore.delete(this, p.slot)
                profiles.remove(p)
                persist()
                refreshAll()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showEditDialog(p: Profile) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_profile, null)
        val spinner = view.findViewById<Spinner>(R.id.spinnerService)
        val labelField = view.findViewById<EditText>(R.id.editLabel)
        val urlField = view.findViewById<EditText>(R.id.editUrl)
        val noteField = view.findViewById<EditText>(R.id.editNote)

        val choices = platforms.filter { !it.hidden || it.key == p.serviceKey }.sortedBy { it.name.lowercase() }
        if (choices.isEmpty()) return
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices.map { it.name })
        spinner.setSelection(choices.indexOfFirst { it.key == p.serviceKey }.coerceAtLeast(0))
        labelField.setText(p.label)
        urlField.setText(p.url)
        noteField.setText(p.note)

        // Ganti platform -> URL dan nama slot terisi otomatis
        var firstSelection = true
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                if (firstSelection) {
                    firstSelection = false
                    return
                }
                val pl = choices[position]
                urlField.setText(pl.url)
                labelField.setText(ProfileStore.nextLabel(profiles, pl, p))
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val builder = AlertDialog.Builder(this)
            .setTitle("Slot ${p.slot}")
            .setView(view)
            .setPositiveButton("Simpan") { _, _ ->
                val pl = choices[spinner.selectedItemPosition]
                p.serviceKey = pl.key
                p.label = labelField.text.toString().ifBlank { pl.name }
                p.url = urlField.text.toString().ifBlank { pl.url }
                p.note = noteField.text.toString().trim()
                persist()
                refreshAll()
            }
            .setNegativeButton("Batal", null)
        if (profiles.size > 1) {
            builder.setNeutralButton("Hapus slot") { _, _ -> confirmDelete(p) }
        }
        builder.show()
    }

    // ---------- limit & countdown ----------

    private fun onToggle(p: Profile, wantOpen: Boolean) {
        if (wantOpen) {
            LimitManager.clear(this, p)
            persist()
            refreshAll()
        } else {
            showLimitDialog(p)
        }
    }

    private fun showLimitDialog(p: Profile) {
        val pl = platformOf(p)
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_limit, null)
        val group = view.findViewById<ChipGroup>(R.id.chipPresets)
        val hours = view.findViewById<EditText>(R.id.editHours)
        val minutes = view.findViewById<EditText>(R.id.editMinutes)

        fun setFields(totalMin: Int) {
            hours.setText((totalMin / 60).toString())
            minutes.setText((totalMin % 60).toString())
        }

        val presets = listOf("30 menit" to 30, "1 jam" to 60, "3 jam" to 180, "5 jam" to 300, "24 jam" to 1440)
        for (preset in presets) {
            val chip = Chip(this)
            chip.text = preset.first
            chip.isCheckable = false
            chip.setOnClickListener { setFields(preset.second) }
            group.addView(chip)
        }
        setFields(pl.defaultLimitMin)

        AlertDialog.Builder(this)
            .setTitle("Limit - ${p.label}")
            .setView(view)
            .setPositiveButton("Mulai") { _, _ ->
                val h = hours.text.toString().toIntOrNull() ?: 0
                val m = minutes.text.toString().toIntOrNull() ?: 0
                val total = h * 60 + m
                if (total <= 0) {
                    Toast.makeText(this, "Isi lama limit lebih dari 0", Toast.LENGTH_SHORT).show()
                    refreshAll()
                } else {
                    LimitManager.setLimit(this, p, total * 60_000L)
                    persist()
                    askNotifPermission()
                    refreshAll()
                    offerAlternative(p)
                }
            }
            .setNegativeButton("Batal") { _, _ -> refreshAll() }
            .setOnCancelListener { refreshAll() }
            .show()
    }

    private fun offerAlternative(p: Profile) {
        val alt = profiles
            .filter { it !== p && it.serviceKey == p.serviceKey && !it.limited }
            .sortedWith(naturalOrder())
            .firstOrNull() ?: return
        AlertDialog.Builder(this)
            .setTitle("Buka ${alt.label}?")
            .setMessage("${p.label} sedang limit. ${alt.label} masih terbuka.")
            .setPositiveButton("Buka") { _, _ -> openProfile(alt) }
            .setNegativeButton("Nanti", null)
            .show()
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------- platform custom ----------

    private fun renderPlatformList() {
        platformList.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (pl in platforms.sortedBy { it.name.lowercase() }) {
            val v = inflater.inflate(R.layout.item_platform, platformList, false)
            IconLoader.bind(
                v.findViewById<FrameLayout>(R.id.iconBox),
                v.findViewById<TextView>(R.id.textLetter),
                v.findViewById<ImageView>(R.id.imageIcon),
                pl
            )
            v.findViewById<TextView>(R.id.textPlatformName).text = pl.name
            v.findViewById<TextView>(R.id.textPlatformUrl).text = pl.url
            v.findViewById<TextView>(R.id.textPlatformTag).text =
                if (pl.hidden) "Disembunyikan" else if (pl.builtin) "Bawaan" else "Custom"
            v.setOnClickListener { showPlatformDialog(pl) }
            platformList.addView(v)
        }
    }

    private fun showPlatformDialog(existing: Platform?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_platform, null)
        val nameField = view.findViewById<EditText>(R.id.editPlatformName)
        val urlField = view.findViewById<EditText>(R.id.editPlatformUrl)
        val colorSpinner = view.findViewById<Spinner>(R.id.spinnerColor)
        val limitField = view.findViewById<EditText>(R.id.editPlatformLimit)

        colorSpinner.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, PlatformStore.COLOR_NAMES)
        if (existing != null) {
            nameField.setText(existing.name)
            urlField.setText(existing.url)
            val ci = PlatformStore.COLOR_HEX.indexOfFirst { it.equals(existing.color, ignoreCase = true) }
            colorSpinner.setSelection(if (ci >= 0) ci else 0)
            limitField.setText(existing.defaultLimitMin.toString())
        } else {
            urlField.setText("https://")
            limitField.setText("60")
        }

        val builder = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah platform" else "Ubah platform")
            .setView(view)
            .setPositiveButton("Simpan") { _, _ ->
                val name = nameField.text.toString().trim()
                var url = urlField.text.toString().trim()
                if (name.isEmpty() || url.isEmpty() || url == "https://") {
                    Toast.makeText(this, "Nama dan alamat situs wajib diisi", Toast.LENGTH_SHORT).show()
                } else {
                    if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                    val limit = (limitField.text.toString().toIntOrNull() ?: 60).coerceAtLeast(1)
                    val color = PlatformStore.COLOR_HEX[colorSpinner.selectedItemPosition]
                    if (existing == null) {
                        platforms.add(Platform(PlatformStore.newKey(), name, url, color, limit))
                    } else {
                        if (existing.url != url) IconLoader.invalidate(this, existing.key)
                        existing.name = name
                        existing.url = url
                        existing.color = color
                        existing.defaultLimitMin = limit
                    }
                    PlatformStore.save(this, platforms)
                    refreshAll()
                }
            }
            .setNegativeButton("Batal", null)

        if (existing != null) {
            if (existing.builtin) {
                builder.setNeutralButton(if (existing.hidden) "Tampilkan" else "Sembunyikan") { _, _ ->
                    existing.hidden = !existing.hidden
                    PlatformStore.save(this, platforms)
                    refreshAll()
                }
            } else {
                builder.setNeutralButton("Hapus") { _, _ ->
                    if (profiles.any { it.serviceKey == existing.key }) {
                        Toast.makeText(this, "Masih dipakai slot. Ubah platform slotnya dulu.", Toast.LENGTH_LONG).show()
                    } else {
                        IconLoader.invalidate(this, existing.key)
                        platforms.remove(existing)
                        PlatformStore.save(this, platforms)
                        refreshAll()
                    }
                }
            }
        }
        builder.show()
    }

    // ---------- kunci aplikasi ----------

    private fun onLockSwitch(on: Boolean) {
        if (on) {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                Toast.makeText(this, "Atur kunci layar (PIN/pola/sidik jari) di HP dulu", Toast.LENGTH_LONG).show()
                switchLock.setOnCheckedChangeListener(null)
                switchLock.isChecked = false
                switchLock.setOnCheckedChangeListener { _, v -> onLockSwitch(v) }
                return
            }
            AppSettings.setLockEnabled(this, true)
            unlocked = true
            leftAt = System.currentTimeMillis()
        } else {
            AppSettings.setLockEnabled(this, false)
        }
    }

    private fun lockIfNeeded() {
        if (!AppSettings.lockEnabled(this)) {
            unlocked = true
            lockOverlay.visibility = View.GONE
            return
        }
        val now = System.currentTimeMillis()
        if (unlocked && now - leftAt < 30_000L) {
            lockOverlay.visibility = View.GONE
            return
        }
        unlocked = false
        lockOverlay.visibility = View.VISIBLE
        requestUnlock()
    }

    private fun requestUnlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val intent = if (km.isDeviceSecure) {
            km.createConfirmDeviceCredentialIntent("AIAgen", "Verifikasi untuk membuka")
        } else {
            null
        }
        if (intent == null) {
            unlocked = true
            lockOverlay.visibility = View.GONE
            Toast.makeText(this, "Kunci layar HP belum diatur, kunci aplikasi tidak aktif", Toast.LENGTH_LONG).show()
        } else {
            unlockLauncher.launch(intent)
        }
    }
}
