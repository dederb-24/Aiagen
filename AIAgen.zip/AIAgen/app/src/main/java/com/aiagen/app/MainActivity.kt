package com.aiagen.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var profiles: MutableList<Profile>
    private lateinit var adapter: ProfileAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        profiles = ProfileStore.load(this)

        val recycler = findViewById<RecyclerView>(R.id.recyclerProfiles)
        recycler.layoutManager = GridLayoutManager(this, 2)
        adapter = ProfileAdapter(
            profiles,
            onOpen = { p -> openProfile(p) },
            onEdit = { p -> showEditDialog(p) }
        )
        recycler.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        // Refresh nama/URL kalau diubah dari dialog
        profiles = ProfileStore.load(this)
        adapter.update(profiles)
    }

    private fun openProfile(p: Profile) {
        val cls = ProfileStore.activityClassFor(p.slot)
        startActivity(Intent(this, cls))
    }

    private fun showEditDialog(p: Profile) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_profile, null)
        val spinner = view.findViewById<Spinner>(R.id.spinnerService)
        val labelField = view.findViewById<EditText>(R.id.editLabel)
        val urlField = view.findViewById<EditText>(R.id.editUrl)

        val serviceLabels = SERVICES.map { it.label }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, serviceLabels)
        spinner.setSelection(SERVICES.indexOfFirst { it.key == p.serviceKey }.coerceAtLeast(0))
        labelField.setText(p.label)
        urlField.setText(p.url)

        AlertDialog.Builder(this)
            .setTitle("Slot ${p.slot}")
            .setView(view)
            .setPositiveButton("Simpan") { _, _ ->
                val svc = SERVICES[spinner.selectedItemPosition]
                p.serviceKey = svc.key
                p.label = labelField.text.toString().ifBlank { svc.label }
                p.url = urlField.text.toString().ifBlank { svc.defaultUrl }
                ProfileStore.save(this, profiles)
                adapter.update(profiles)
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

class ProfileAdapter(
    private var items: List<Profile>,
    private val onOpen: (Profile) -> Unit,
    private val onEdit: (Profile) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.textLabel)
        val subtitle: TextView = view.findViewById(R.id.textService)
    }

    fun update(newItems: List<Profile>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        val svc = SERVICES.first { it.key == p.serviceKey }
        holder.title.text = p.label
        holder.subtitle.text = svc.label
        holder.itemView.setOnClickListener { onOpen(p) }
        holder.itemView.setOnLongClickListener { onEdit(p); true }
    }

    override fun getItemCount() = items.size
}
